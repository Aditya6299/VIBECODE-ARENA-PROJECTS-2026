# QueueSmart AI

Smart queue management prototype: a customer portal and an admin dashboard working on one shared, simulated dataset. Plain HTML, CSS and JavaScript. No backend and no build step. Data is stored in the browser (localStorage).

## Run it

- Quickest: open `index.html` in a browser.
- VS Code: install the recommended extension "Live Server", right-click `index.html`, choose "Open with Live Server".
- npm: run `npm install`, then `npm start`, and open http://localhost:5173

## Check it

- `npm test` runs 83 checks in jsdom. They click the real buttons and fill the real forms. A 500-step randomised run also asserts after every step that no token is served twice, no counter is double-booked, estimates match the formula, and priority and first-come-first-served ordering hold.
- `npm run lint` runs ESLint (undefined variables, redeclarations, unreachable code, unused variables).
- Not covered by these checks: real-browser rendering. Look at the layout yourself at about 375, 768 and 1280 px, in light and dark mode.

## Files

| File | Holds |
|---|---|
| index.html | Page shell and navigation |
| styles.css | Styling, light and dark themes |
| app.js | State and seed data, queue engine, insights, views, events (in that order) |
| tests/queuesmart.test.js | Test suite |
| package.json, .eslintrc.json | Tooling |

In `app.js` the queue logic is `wq` (ordering), `info` and `est` (position and wait), `callNext`, `complete`, `tog`, `cset`, `addC` (counter and token actions) and `ins`, `reco` (insights). The views only read that state.

## Rules the demo follows

- Wait estimate = ceil((people ahead + people being served) x service minutes / open counters for that service). It is a baseline estimate, not a promise. With no open counter it shows "Unavailable".
- Priority: Accessibility Assistance, then Eligible Appointment, then General. Ranks are editable in Admin. First come, first served inside a rank.
- Accessibility priority needs a staff code. Demo code: `ACCESS-1`.
- Appointments stay Booked until 15 minutes before their time (editable), then join the queue. Admin has "Advance demo clock +30 min" to show this.
- Overcrowding by waiting customers per service: Normal up to 5, Moderate 6-10, High 11-15, Critical above 15 (editable). Insights are rule-based. There is no trained model.
- The Admin switch is a demonstration role switch, not authentication.

## Two-minute demo

1. Admin: Account Opening shows a Moderate alert with the rule that triggered it. Click Apply on "Reassign Counter 3". Its estimates drop.
2. Document Verification shows "Unavailable (no open counter)". Apply "Open Counter 5" and it gets an estimate.
3. Customer portal: register a Cash Services customer, note the token, position and estimate. In Admin, Call next on Counter 3, then Complete. Watch the status, counts and notifications change.
4. Register an Accessibility customer (code `ACCESS-1`) for Account Opening. They go ahead of general customers. Change the ranks in Admin settings and the order flips.
5. Book an appointment slot (status Booked), then advance the demo clock +30 min (it joins the queue).
6. Register more Account Opening customers to reach High (11 waiting) and Critical (16).
7. Reload to show persistence. Use Reset demo data to start over.

## Known limits

- Not React or Vite, no icon library, no dedicated loading states.
- Appointment management covers bookings per slot and the eligibility window, not blocking single slots.
- The accessibility code is visible in Admin and anyone with a token number can cancel it. This is demo-grade.
- The estimate counts everyone being served as fully ahead of you, so a first-in-line customer can show a wait while another counter is idle.
- Data lives in one browser. There is no sync across tabs or devices. To reset by hand, clear the localStorage key `qs_v1` or use Reset demo data.
