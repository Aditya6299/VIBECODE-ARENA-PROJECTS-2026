// QueueSmart AI regression tests. Run: npm test
const {JSDOM,VirtualConsole}=require('jsdom'),fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..');
const H=fs.readFileSync(path.join(root,'index.html'),'utf8').replace(/<script src="([^"]+)"><\/script>/g,(m,f)=>'<script>'+fs.readFileSync(path.join(root,f),'utf8')+'</script>');
const errs=[],bad=[];let pass=0;
const ok=(c,m)=>{c?pass++:bad.push(m)},run=(n,f)=>{try{f()}catch(e){bad.push(n+' threw: '+e.message)}};
const INV=`(()=>{const e=[],ids=S.tok.map(t=>t.id);if(new Set(ids).size!=ids.length)e.push('duplicate token id');
S.ctr.forEach(c=>{if(c.tok){const t=tk(c.tok);if(!t||t.st!='Serving'||t.ctr!=c.id)e.push('bad counter link '+c.id);else if(t.svc!=c.svc)e.push('incompatible '+c.id);if(!c.open)e.push('busy but closed '+c.id)}});
const used={};S.tok.forEach(t=>{if(t.st=='Serving'){const c=ct(t.ctr);if(!c||c.tok!=t.id)e.push('serving without counter '+t.id);if(used[t.ctr])e.push('counter double-booked');used[t.ctr]=1}
if(['Completed','Cancelled'].includes(t.st)&&S.ctr.some(c=>c.tok==t.id))e.push('finished token on counter');
if(t.st=='Waiting'&&t.qts>now())e.push('waiting before window '+t.id);if(t.st=='Booked'&&t.qts<=now())e.push('booked past window '+t.id)});
S.svc.forEach(v=>{const q=wq(v.id),c=openC(v.id).length;q.forEach((t,i)=>{const n=info(t),x=c?Math.ceil((i+serving(v.id))*v.avg/c):null;if(n.pos!=i+1)e.push('position '+t.id);if(n.wait!==x)e.push('estimate '+t.id);if(n.wait!=null&&n.wait<0)e.push('negative wait')});
for(let i=1;i<q.length;i++)if(rk(q[i-1])>rk(q[i])||rk(q[i-1])==rk(q[i])&&q[i-1].qts>q[i].qts)e.push('ordering '+v.id)});return e.join('; ')})()`;
function boot(ls){const vc=new VirtualConsole();vc.on('jsdomError',e=>{if(!/stylesheet|CSS/i.test(e.message))errs.push(e.message)});vc.on('error',m=>errs.push(String(m)));
 const d=new JSDOM(H,{runScripts:'dangerously',url:'https://qs.test/',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){for(const k in ls||{})w.localStorage.setItem(k,ls[k]);w.addEventListener('error',e=>errs.push('uncaught: '+e.message))}});
 const w=d.window,doc=w.document,t={w,doc,ev:s=>w.eval(s),S:()=>w.eval('S'),txt:()=>doc.body.textContent,toasts:()=>doc.querySelectorAll('#ts .t.x').length,
 lastErr:()=>[...doc.querySelectorAll('#ts .t.x')].pop().textContent,
 clk(a,v){const b=doc.querySelector(`[data-a=${a}]`+(v!=null?`[data-v="${v}"]`:''));if(!b)throw Error('no button '+a+' '+v);if(b.disabled)throw Error('disabled '+a+' '+v);b.click()},
 set(n,v){const e=doc.querySelector(`[name=${n}]`);if(!e)throw Error('no field '+n);e.value=v;e.dispatchEvent(new w.Event('input',{bubbles:true}));e.dispatchEvent(new w.Event('change',{bubbles:true}))},
 sub(f){doc.querySelector(`form[data-f=${f}]`).dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}))},
 reg(o){t.clk('tab','c');t.set('name',o.n||'Test User');t.set('ph',o.ph||'9876543210');t.set('svc',o.s||'CS');t.set('pri',o.p||'GEN');if(o.p=='ACC')t.set('code',o.c||'');t.set('slot',o.slot||'');t.sub('reg')},
 rst(){t.clk('tab','a');t.clk('reset')}};
 return t}
let t=boot();const S=()=>t.S(),tok=i=>t.ev(`tk("${i}")`),inv=m=>ok(t.ev(INV)=='',m+' invariants: '+t.ev(INV));
run('seed',()=>{ok(S().tok.length==20&&S().ctr.length==5,'seed: 20 tokens, 5 counters');ok(S().ctr.some(c=>!c.open),'seed: closed counter');ok(['Waiting','Serving','Completed','Booked'].every(s=>S().tok.some(x=>x.st==s)),'seed: all statuses present');ok(t.ev('ins().some(r=>r.L>0)'),'seed: overcrowding alert');inv('seed')});
run('T1',()=>{t.reg({n:'Zed Test',s:'CS'});const id=S().my[0];ok(id=='QS-CS-021','T1 token id '+id);ok(t.txt().includes(id),'T1 confirmation shows token');ok(new Set(S().tok.map(x=>x.id)).size==S().tok.length,'T1 unique ids');
 t.reg({n:'A'});ok(/full name/.test(t.txt()),'T1 name validation');t.reg({n:'Zed',ph:'123'});ok(/10-digit/.test(t.txt()),'T1 phone validation');ok(S().my.length==1,'T1 invalid forms create no token')});
run('T2',()=>{t.reg({n:'Second',s:'CS'});const[a,b]=S().my;ok(t.ev(`info(tk("${a}")).pos`)==1&&t.ev(`info(tk("${b}")).pos`)==2,'T2 positions 1,2');ok(t.ev(`info(tk("${a}")).wait`)==2&&t.ev(`info(tk("${b}")).wait`)==4,'T2 estimates 2 and 4 min');inv('T2')});
run('T3/T4',()=>{const a=S().my[0];t.clk('tab','a');t.clk('call','C3');ok(tok(a).st=='Serving'&&t.ev('ct("C3").tok')==a,'T3 token serving on C3');ok(t.ev(`info(tk("${S().my[1]}")).pos`)==1,'T3 next token moves to position 1');inv('T3');
 const n=t.ev('S.tok.filter(x=>x.st=="Completed").length');t.clk('done','C3');ok(t.ev('ct("C3").tok')===null&&tok(a).st=='Completed'&&tok(a).end>0,'T4 counter released, end time set');ok(t.ev('S.tok.filter(x=>x.st=="Completed").length')==n+1,'T4 completed +1');
 const c=[...t.doc.querySelectorAll('.st')].find(e=>/Completed/.test(e.textContent));ok(c&&c.querySelector('b').textContent==String(n+1),'T4 dashboard card shows live count');inv('T4')});
run('T5',()=>{const b=S().my[1],w0=t.ev(`info(tk("${b}")).wait`);t.clk('tog','C3');ok(t.ev('openC("CS").length')==1,'T5 close reduces capacity');const w1=t.ev(`info(tk("${b}")).wait`);ok(w1>w0,`T5 estimate rises (${w0}->${w1})`);
 t.clk('tog','C3');ok(t.ev(`info(tk("${b}")).wait`)==w0,'T5 estimate restored on reopen');const e=t.toasts();t.clk('tog','C2');ok(t.ev('ct("C2").open')===true&&t.toasts()>e,'T5 closing busy counter blocked');inv('T5')});
run('T6',()=>{t.rst();const e=t.toasts(),s0=t.ev('S.tok.filter(x=>x.st=="Serving").length');t.clk('next');ok(t.toasts()>e&&/Cannot call/.test(t.lastErr()),'T6 explains why no call is possible');ok(t.ev('S.tok.filter(x=>x.st=="Serving").length')==s0,'T6 no state change');
 t.ev('callNext("C5")');ok(/closed/.test(t.lastErr()),'T6 closed counter refused');t.clk('tab','c');ok(/Unavailable \(no open counter\)/.test(t.txt()),'T6 estimate unavailable shown');inv('T6')});
run('T7',()=>{t.rst();ok(t.ev('wq("AO")[0].pri')=='ACC','T7 seeded ACC token first');t.reg({n:'Wrong',s:'AO',p:'ACC',c:'nope'});ok(/verification code/.test(t.txt())&&S().my.length==0,'T7 invalid ACC code rejected');
 t.reg({n:'Acc New',s:'AO',p:'ACC',c:'access-1'});const id=S().my[0];t.reg({n:'Gen New',s:'AO'});const g=S().my[1],o=t.ev('wq("AO").map(x=>x.id)');
 ok(o[1]==id&&o[o.length-1]==g&&tok(id).pri=='ACC','T7 new ACC behind earlier ACC (FIFO), ahead of GEN; new GEN last');inv('T7')});
run('T8',()=>{t.rst();const sl=t.ev('slots("DV")[0].ts'),q0=t.ev('wq("DV").length');t.reg({n:'Appt One',s:'DV',slot:String(sl)});const id=S().my[0];
 ok(tok(id).st=='Booked'&&tok(id).pri=='APT'&&t.ev('wq("DV").length')==q0,'T8 booked, not in active queue');t.reg({n:'Appt Two',s:'DV',slot:String(sl)});t.reg({n:'Appt Three',s:'DV',slot:String(sl)});
 ok(/full or unavailable/.test(t.txt())&&S().my.length==2,'T8 slot capacity enforced');t.clk('tab','a');t.clk('clock');ok(tok(id).st=='Waiting'&&t.ev(`wq("DV").indexOf(tk("${id}"))`)>=0,'T8 eligible after window opens');
 ok(t.ev('S.tok.filter(x=>x.appt&&x.st=="Booked").every(x=>x.qts>now())'),'T8 remaining bookings still outside window');inv('T8')});
run('T9',()=>{t.rst();ok(t.ev('[0,5,6,10,11,15,16].map(lvl).join()')=='0,0,1,1,2,2,3','T9 level boundaries');t.clk('tab','a');ok(/Account Opening: Moderate/.test(t.txt()),'T9 seeded Moderate alert');
 for(let i=0;i<4;i++)t.reg({n:'Crowd'+i,s:'AO'});t.clk('tab','a');ok(/Account Opening: High/.test(t.txt()),'T9 High at 11');
 for(let i=0;i<5;i++)t.reg({n:'Crowd'+i,s:'AO'});t.clk('tab','a');ok(/Account Opening: Critical/.test(t.txt())&&t.doc.querySelector('.al.a3'),'T9 Critical at 16');inv('T9')});
run('T10',()=>{t.rst();t.clk('tab','a');ok(t.ev('ins().sort((a,b)=>b.wl-a.wl)[0].v.id')=='AO','T10 AO top workload');ok(/Reassign Counter 3 to Account Opening/.test(t.txt()),'T10 recommends idle CS counter for AO');
 t.clk('apply','C3|AO|0');ok(t.ev('ct("C3").svc')=='AO'&&t.ev('openC("AO").length')==2,'T10 apply reassigns counter');
 ok(/Call next/.test(t.ev('reco(ins().find(r=>r.v.id=="AO")).t')),'T10 idle counter already on the queue -> recommend calling next');
 t.clk('apply','C5|DV|1');ok(t.ev('ct("C5").open')===true&&t.ev('info(wq("DV")[0]).wait')!==null,'T10 opening DV counter makes estimate available');inv('T10')});
run('T11',()=>{t.rst();const has=r=>S().notes.filter(n=>r.test(n.m)).length;t.reg({n:'Notify',s:'CS'});ok(has(/Registration successful/)==1,'T11 one registration note');ok(has(/approaching/)>=1,'T11 approaching note');
 const n1=S().notes.length;for(let i=0;i<5;i++)t.ev('refresh()');ok(S().notes.length==n1,'T11 no duplicates on re-render/refresh');
 t.clk('tab','a');t.clk('done','C1');ok(has(/service completed/)==1,'T11 completed note');t.clk('call','C1');ok(has(/is called to Counter 1/)==1,'T11 called note');ok(has(/estimated wait changed/)>=1,'T11 estimate-changed note');
 t.clk('clock');const e=has(/appointment is eligible/);ok(e>=1,'T11 eligibility note');t.clk('clock');const el=S().notes.filter(n=>/appointment is eligible/.test(n.m)).map(n=>n.t);ok(new Set(el).size==el.length,'T11 eligibility note never repeated for the same token');
 for(let i=0;i<4;i++)t.reg({n:'C'+i,s:'AO'});ok(has(/now High/)==1,'T11 delay note once on escalation');t.ev('refresh()');ok(has(/now High/)==1,'T11 delay note not repeated');
 t.clk('tab','a');t.clk('tog','C3');ok(has(/Counter disruption/)==1,'T11 counter disruption note');inv('T11')});
run('T12',()=>{const ls={qs_v1:t.w.localStorage.getItem('qs_v1')},a=JSON.parse(ls.qs_v1),t2=boot(ls);
 ok(t2.S().tok.length==a.tok.length&&t2.S().seq==a.seq&&t2.S().my.length==a.my.length&&JSON.stringify(t2.S().ctr)==JSON.stringify(a.ctr)&&t2.S().notes.length==a.notes.length,'T12 state restored after reload');ok(t2.ev(INV)=='','T12 invariants after reload');
 ok(boot({qs_v1:'{broken'}).S().tok.length==20,'T12 corrupt JSON -> defaults');ok(boot({qs_v1:'{"tok":[1]}'}).S().tok.length==20,'T12 wrong shape -> defaults');
 const b1=JSON.parse(ls.qs_v1);b1.ctr[0].tok='QS-ZZ-999';ok(boot({qs_v1:JSON.stringify(b1)}).S().ctr[0].tok!=='QS-ZZ-999','T12 counter pointing at ghost token rejected');
 const b2=JSON.parse(ls.qs_v1);b2.tok[0].svc='XX';ok(boot({qs_v1:JSON.stringify(b2)}).S().tok[0].svc!=='XX','T12 token with unknown service rejected')});
run('extras',()=>{t.rst();t.clk('tab','c');const q=t.doc.querySelector('#q'),id=S().tok[0].id;q.value=id;q.dispatchEvent(new t.w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));ok(t.ev('mine')==id,'Enter key runs token search');
 t.rst();t.clk('tab','c');const f=n=>t.doc.querySelector(`[name=${n}]`),n0=S().tok.length;f('name').value='Auto Fill';f('ph').value='9123456789';t.sub('reg');ok(S().tok.length==n0+1,'submit reads current field values (autofill)');
 t.clk('tab','a');t.set('t0',12);t.set('t1',8);const e=t.toasts();t.sub('cfg');ok(t.toasts()>e&&t.ev('S.th.join()')=='5,10,15','settings: invalid thresholds rejected');
 t.set('t0',8);t.set('t1',12);t.set('t2',20);t.sub('cfg');ok(t.ev('S.th.join()')=='8,12,20'&&t.ev('ins().find(r=>r.v.id=="AO").L')==0,'settings: thresholds change level');
 t.set('rACC',3);t.set('rGEN',1);t.set('rAPT',2);t.sub('cfg');ok(t.ev('wq("AO")[0].pri')=='GEN','settings: rank change reorders queue');
 t.set('rACC',1);t.set('rGEN',1);const e1=t.toasts();t.sub('cfg');ok(t.toasts()>e1,'settings: duplicate ranks rejected');inv('settings');
 t.rst();t.set('n','Counter 6');t.set('v','AO');t.sub('add');ok(t.ev('S.ctr.length')==6&&t.ev('ct("C6").open')===false,'add counter: created closed');const w0=t.ev('info(wq("AO")[0]).wait');t.clk('tog','C6');ok(t.ev('info(wq("AO")[0]).wait')<w0,'add counter: opening lowers AO estimates');
 const e2=t.toasts();t.set('n','counter 6');t.sub('add');ok(t.toasts()>e2&&t.ev('S.ctr.length')==6,'add counter: duplicate name rejected');inv('add counter')});
run('buttons',()=>{t.rst();['c','a'].forEach(v=>{t.clk('tab',v);for(let i=0;;i++){const bs=[...t.doc.querySelectorAll('#app button:not([disabled])')].filter(b=>b.dataset.a!='reset');if(i>=bs.length)break;bs[i].click()}inv('click-all '+v)})});
run('fuzz',()=>{t=boot();let s=12345;const r=()=>(s=(s*1103515245+12345)&0x7fffffff)/0x7fffffff,pk=a=>a[Math.floor(r()*a.length)];
 for(let i=0;i<500;i++){const S0=t.S(),a=Math.floor(r()*9),J=JSON.stringify;
  if(a<2)t.reg({n:'Fz'+i,s:pk(['AO','CS','SU','DV']),p:r()<.2?'ACC':'GEN',c:'ACCESS-1',slot:r()<.2?String(t.ev(`slots("AO")[${Math.floor(r()*6)}].ts`)):''});
  else if(a==2)t.ev('callNext()');else if(a==3)t.ev(`callNext(${J(pk(S0.ctr).id)})`);else if(a==4)t.ev(`complete(${J(pk(S0.ctr).id)})`);else if(a==5)t.ev(`tog(${J(pk(S0.ctr).id)})`);
  else if(a==6)t.ev(`cset(${J(pk(S0.ctr).id)},${J(pk(S0.svc).id)},0)`);else if(a==7){const x=S0.tok.filter(k=>['Booked','Waiting'].includes(k.st));if(x.length)t.ev(`A.cancel(${J(pk(x).id)})`)}else t.ev('A.clock()');
  const v=t.ev(INV);if(v){bad.push('fuzz step '+i+' action '+a+': '+v);break}}ok(true,'')});
console.log(JSON.stringify({passed:pass,failed:bad.length,failures:bad,jsErrors:[...new Set(errs)]},null,1));process.exit(bad.length||errs.length?1:0);
