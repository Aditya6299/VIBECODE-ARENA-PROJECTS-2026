const $=s=>document.querySelector(s),E=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const M=6e4,K='qs_v1',hm=t=>new Date(t).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}),PN={ACC:'Accessibility Assistance',APT:'Eligible Appointment',GEN:'General'},LN=['Normal','Moderate','High','Critical'];
let S,view='c',mine=null,D={svc:'CS',pri:'GEN',slot:''},Q=0;
/* ---------- queue engine (all calculations live here) ---------- */
const now=()=>Date.now()+S.skew,sv=i=>S.svc.find(x=>x.id==i),ct=i=>S.ctr.find(x=>x.id==i),tk=i=>S.tok.find(x=>x.id==i);
const openC=v=>S.ctr.filter(c=>c.svc==v&&c.open),rk=t=>S.rank[t.pri];
const wq=v=>S.tok.filter(t=>t.svc==v&&t.st=='Waiting').sort((a,b)=>rk(a)-rk(b)||a.qts-b.qts||a.reg-b.reg);
const serving=v=>S.tok.filter(t=>t.svc==v&&t.st=='Serving').length;
const est=(a,v)=>{const c=openC(v).length;return c?Math.ceil(a*sv(v).avg/c):null};
const info=t=>{if(t.st!='Waiting')return{};const p=wq(t.svc).indexOf(t)+1;return{pos:p,wait:est(p-1+serving(t.svc),t.svc)}};
const lvl=n=>n>S.th[2]?3:n>S.th[1]?2:n>S.th[0]?1:0;
const W=w=>w==null?'Unavailable (no open counter)':w==0?'Next in line':'~'+w+' min';
const wt=t=>t.st=='Waiting'?W(info(t).wait):t.st=='Serving'?'Being served':t.st=='Booked'?'Joins queue '+hm(t.qts):'-';
const bd=s=>`<span class="b ${s}">${s}</span>`;
function seed(){
 const n=Date.now(),s={skew:0,seq:0,cap:2,win:15,th:[5,10,15],rank:{ACC:1,APT:2,GEN:3},code:'ACCESS-1',my:[],notes:[],seen:{},lv:{},
 svc:[['AO','Account Opening',10],['CS','Cash Services',4],['SU','Customer Support',7],['DV','Document Verification',6]].map(([id,name,avg])=>({id,name,avg})),
 ctr:[['C1','AO',1],['C2','CS',1],['C3','CS',1],['C4','SU',1],['C5','DV',0]].map(([id,svc,o])=>({id,name:'Counter '+id[1],svc,open:!!o,tok:null})),tok:[]};
 const N='Aarav Mehta,Isha Verma,Rohan Gupta,Meera Nair,Kabir Singh,Anaya Rao,Dev Patel,Sana Khan,Vikram Joshi,Tara Iyer,Arjun Das,Naina Shah,Rahul Jain,Pooja Menon,Imran Ali,Kavya Reddy,Nikhil Sethi,Divya Pillai,Yash Kapoor,Leela Bose'.split(',');
 /* svc, priority, minutes since registration, status, counter, start ago, end ago, appointment in */
 const R=[['CS','GEN',55,'Completed','C2',50,46],['SU','GEN',50,'Completed','C4',44,37],['DV','GEN',48,'Completed','C5',42,36],['CS','GEN',40,'Completed','C3',36,32],
 ['AO','GEN',38,'Serving','C1',6],['SU','GEN',25,'Serving','C4',3],['CS','GEN',20,'Serving','C2',2],
 ['AO','GEN',30,'Waiting'],['AO','GEN',27,'Waiting'],['AO','GEN',24,'Waiting'],['AO','GEN',21,'Waiting'],['AO','ACC',16,'Waiting'],['AO','GEN',12,'Waiting'],['AO','GEN',8,'Waiting'],
 ['SU','GEN',15,'Waiting'],['SU','GEN',9,'Waiting'],['DV','GEN',11,'Waiting'],
 ['AO','APT',90,'Booked',0,0,0,45],['DV','APT',80,'Booked',0,0,0,75],['SU','APT',70,'Booked',0,0,0,100]];
 R.sort((a,b)=>b[2]-a[2]).forEach(([v,p,ra,st,c,sa,ea,ap],i)=>{s.seq++;const reg=n-ra*M,t={id:`QS-${v}-${String(s.seq).padStart(3,'0')}`,name:N[i],svc:v,pri:p,reg,appt:ap?n+ap*M:null,st,ctr:c||null,start:sa?n-sa*M:null,end:ea?n-ea*M:null,est:null};
  t.qts=t.appt?t.appt-s.win*M:reg;s.tok.push(t);if(st=='Serving')s.ctr.find(x=>x.id==c).tok=t.id});
 return s}
function sane(j){try{const vs=new Set(j.svc.map(v=>v.id)),ids=new Set(j.tok.map(t=>t.id)),cs=new Set(j.ctr.map(c=>c.id));
 return typeof j.skew=='number'&&j.th.every(Number.isFinite)&&ids.size==j.tok.length&&cs.size==j.ctr.length&&
 j.tok.every(t=>vs.has(t.svc)&&j.rank[t.pri]&&['Booked','Waiting','Serving','Completed','Cancelled'].includes(t.st)&&(t.st!='Serving'||j.ctr.some(c=>c.id==t.ctr&&c.tok==t.id)))&&
 j.ctr.every(c=>vs.has(c.svc)&&(!c.tok||j.tok.some(t=>t.id==c.tok&&t.st=='Serving'&&t.ctr==c.id)))}catch(e){return false}}
function load(){try{const j=JSON.parse(localStorage.getItem(K));if(j&&Array.isArray(j.tok)&&Array.isArray(j.ctr)&&Array.isArray(j.svc)&&j.rank&&j.th&&j.th.length==3&&j.notes&&j.seen&&j.lv&&j.my&&sane(j))return j}catch(e){}return seed()}
const save=()=>{try{localStorage.setItem(K,JSON.stringify(S))}catch(e){}};
const toast=(m,x)=>{const d=document.createElement('div');d.className='t'+(x?' x':'');d.textContent=m;$('#ts').append(d);setTimeout(()=>d.remove(),4500)};
const fail=m=>{toast(m,1);return false};
function note(m,k,t){if(k&&S.seen[k])return;if(k)S.seen[k]=1;if(Q)return;S.notes.unshift({ts:now(),m,t:t||null});S.notes.length=Math.min(S.notes.length,40);toast(m)}
function refresh(tick){
 S.tok.forEach(t=>{if(t.st=='Booked'&&now()>=t.qts){t.st='Waiting';note(`${t.id}: appointment is eligible and has joined the ${sv(t.svc).name} queue`,'el:'+t.id,t.id)}});
 S.svc.forEach(v=>{const q=wq(v.id);q.forEach((t,i)=>{const w=info(t).wait;
  if(i<2)note(`${t.id}: your turn is approaching (position ${i+1})`,'nr:'+t.id,t.id);
  if(w!=null&&t.est!=null&&Math.abs(w-t.est)>=5)note(`${t.id}: estimated wait changed from ~${t.est} to ~${w} min`,0,t.id);t.est=w});
  const L=lvl(q.length);if(L>(S.lv[v.id]||0))note(`Queue delay: ${v.name} is now ${LN[L]} (${q.length} waiting)`,0);S.lv[v.id]=L});
 save();const a=document.activeElement;if(tick&&a&&/INPUT|SELECT/.test(a.tagName))return;render()}
function slots(v){const o=[],b=Math.ceil((now()+S.win*M)/(30*M))*30*M;for(let i=0;i<6;i++){const ts=b+i*30*M;o.push({ts,left:S.cap-S.tok.filter(t=>t.svc==v&&t.appt==ts&&t.st!='Cancelled').length})}return o}
function reg(){const d=D,name=(d.name||'').trim(),sl=d.slot?slots(d.svc).find(x=>x.ts==d.slot):null;let e='';
 if(name.length<2)e='Enter your full name (at least 2 characters).';
 else if(!/^\d{10}$/.test(d.ph||''))e='Enter a 10-digit mobile number. Demo only: no SMS is sent.';
 else if(!sv(d.svc))e='Choose an available service.';
 else if(d.pri=='ACC'&&(d.code||'').trim().toUpperCase()!=S.code)e='Accessibility priority needs a valid staff verification code. Ask staff, or find the demo code under Admin, Priority policy.';
 else if(d.slot&&(!sl||sl.left<1))e='That appointment slot is full or unavailable. Choose another slot.';
 if(e){D.err=e;return render()}
 const ts=now(),ap=d.slot?+d.slot:null;S.seq++;
 const t={id:`QS-${d.svc}-${String(S.seq).padStart(3,'0')}`,name,ph:d.ph,svc:d.svc,pri:d.pri=='ACC'?'ACC':ap?'APT':'GEN',reg:ts,appt:ap,qts:ap?ap-S.win*M:ts,st:ap?'Booked':'Waiting',ctr:null,start:null,end:null,est:null};
 S.tok.push(t);S.my.push(t.id);mine=t.id;D={svc:d.svc,pri:'GEN',slot:''};
 note(`Registration successful: your token is ${t.id}`,'rg:'+t.id,t.id);
 if(ap)note(`Appointment booked for ${hm(ap)} (${sv(t.svc).name}). You join the queue at ${hm(t.qts)}.`,'bk:'+t.id,t.id);
 refresh()}
function callNext(cid){
 const idle=S.ctr.filter(c=>c.open&&!c.tok&&(!cid||c.id==cid)),c0=cid&&ct(cid);
 if(cid&&!idle.length)return fail(`${c0.name} cannot take a token: it is ${c0.open?'busy':'closed'}.`);
 if(cid&&!wq(c0.svc).length)return fail(`${c0.name} has nobody waiting for ${sv(c0.svc).name}.`);
 let b=null;idle.forEach(c=>{const t=wq(c.svc)[0];if(t&&(!b||rk(t)<rk(b.t)||rk(t)==rk(b.t)&&t.qts<b.t.qts))b={c,t}});
 if(!b){const w=S.svc.filter(v=>wq(v.id).length);return fail(w.length?`Cannot call: ${w.map(v=>v.name).join(', ')} ha${w.length>1?'ve':'s'} waiting customers but no idle open counter assigned. Open or reassign a counter.`:'No eligible waiting tokens to call.')}
 if(b.t.st!='Waiting'||b.c.tok||!b.c.open||b.c.svc!=b.t.svc)return fail('Invalid assignment blocked.');
 b.t.st='Serving';b.t.ctr=b.c.id;b.t.start=now();b.c.tok=b.t.id;
 note(`${b.t.id} is called to ${b.c.name}`,'cl:'+b.t.id,b.t.id);refresh()}
function complete(id){const c=ct(id),t=c&&tk(c.tok);if(!t||t.st!='Serving')return fail(`${c?c.name:'Counter'} has no active service to complete.`);
 t.st='Completed';t.end=now();c.tok=null;note(`${t.id}: service completed. Thank you!`,'dn:'+t.id,t.id);refresh()}
function tog(id){const c=ct(id);if(c.open){if(c.tok)return fail(`${c.name} is serving ${c.tok}. Complete that service before closing.`);c.open=false;
 note(`Counter disruption: ${c.name} closed${openC(c.svc).length?'':'. '+sv(c.svc).name+' has no open counter'}`,0)}else{c.open=true;note(`${c.name} opened for ${sv(c.svc).name}`,0)}refresh()}
function cset(id,v,o){const c=ct(id);if(!sv(v))return fail('Unknown service.');if(c.tok)return fail(`${c.name} is serving ${c.tok}. Complete it before changing the assignment.`);
 c.svc=v;if(o)c.open=true;note(`${c.name} now serves ${sv(v).name}${o?' (opened)':''}`,0);refresh();return 1}
function addC(n,v){n=(n||'').trim();if(!n)return fail('Enter a counter name.');if(S.ctr.some(c=>c.name.toLowerCase()==n.toLowerCase()))return fail('A counter with that name already exists.');
 S.ctr.push({id:'C'+(Math.max(0,...S.ctr.map(c=>+c.id.slice(1)))+1),name:n,svc:v,open:false,tok:null});toast(`${n} added (closed). Open it to add capacity.`);refresh()}
function cfg(f){const g=k=>+f.get(k),t=[g('t0'),g('t1'),g('t2')],r={ACC:g('rACC'),APT:g('rAPT'),GEN:g('rGEN')},cap=g('cap'),win=g('win');
 if(t.some(x=>!Number.isInteger(x)||x<0)||t[0]>=t[1]||t[1]>=t[2])return fail('Thresholds must be whole numbers in increasing order.');
 if(new Set(Object.values(r)).size<3)return fail('Each priority category needs a different rank (1 = highest).');
 if(!(cap>=1&&cap<=10)||!(win>=0&&win<=120))return fail('Appointments per slot must be 1 to 10 and the window 0 to 120 minutes.');
 S.th=t;S.rank=r;S.cap=cap;S.win=win;S.tok.forEach(x=>{if(x.appt&&x.st=='Booked')x.qts=x.appt-win*M});toast('Settings saved');refresh()}
/* ---------- rule-based insights ---------- */
function ins(){return S.svc.map(v=>{const w=wq(v.id).length;return{v,w,oc:openC(v.id).length,L:lvl(w),wl:w*v.avg,dm:S.tok.filter(t=>t.svc==v.id).length,lw:est(w+serving(v.id),v.id)}})}
function reco(r){const v=r.v,why=`${v.name} has ${r.w} waiting, ${r.oc} open counter(s) and a workload of ${r.wl} min.`;
 let a=S.ctr.find(c=>c.open&&!c.tok&&c.svc==v.id&&r.w);
 if(a)return{t:`Call next token on ${a.name}`,why:why+` ${a.name} is open, idle and already assigned to ${v.name}.`,call:a.id};
 a=S.ctr.find(c=>c.open&&!c.tok&&c.svc!=v.id&&!wq(c.svc).length&&openC(c.svc).length>1);
 if(a)return{t:`Reassign ${a.name} to ${v.name}`,why:why+` ${a.name} is idle and ${sv(a.svc).name} has nobody waiting.`,ap:[a.id,v.id,0]};
 a=S.ctr.find(c=>!c.open&&!c.tok);
 if(a)return{t:`Open ${a.name} and assign it to ${v.name}`,why:why+` ${a.name} is closed and free to use.`,ap:[a.id,v.id,1]};
 return{t:'Keep the current allocation and tell waiting customers about the delay',why:why+' No idle or closed counter is available to add.'}}
/* ---------- views ---------- */
function tbl(adm){const o=S.svc.flatMap(v=>[...S.tok.filter(t=>t.svc==v.id&&t.st=='Serving'),...wq(v.id),...S.tok.filter(t=>t.svc==v.id&&t.st=='Booked').sort((a,b)=>a.appt-b.appt)]);
 return o.length?`<div class=tw><table><tr><th>Token</th>${adm?'<th>Customer</th>':''}<th>Service</th><th>Priority</th><th>Position</th><th>Estimated Wait</th><th>Status</th>${adm?'<th>Appointment</th><th></th>':''}</tr>${o.map(t=>`<tr class="${t.id==mine?'me':''}"><td><b>${t.id}</b></td>${adm?`<td>${E(t.name)}</td>`:''}<td>${sv(t.svc).name}</td><td>${PN[t.pri]}</td><td>${info(t).pos||'-'}</td><td>${wt(t)}</td><td>${bd(t.st)}</td>${adm?`<td>${t.appt?hm(t.appt):'-'}</td><td>${t.st=='Serving'?'':`<button class=dg data-a=cancel data-v=${t.id}>Cancel</button>`}</td>`:''}</tr>`).join('')}</table></div>`:'<p class=m>No active tokens yet. Register a customer to create the first one.</p>'}
function card(t){const i=info(t),q=wq(t.svc).length;return `<div style="margin-top:10px;border-top:1px solid var(--bd);padding-top:10px"><div class=r><h2 style="margin:0">${t.id}</h2>${bd(t.st)}</div>
<div class=tw><table><tr><th>Service</th><td>${sv(t.svc).name}</td></tr><tr><th>Registered</th><td>${hm(t.reg)}</td></tr><tr><th>Priority</th><td>${PN[t.pri]}</td></tr><tr><th>Queue position</th><td>${i.pos?i.pos+' of '+q:'-'}</td></tr><tr><th>Estimated wait</th><td>${wt(t)} <span class=m>(estimate, not a guarantee)</span></td></tr>${t.appt?`<tr><th>Appointment</th><td>${hm(t.appt)}, joins queue at ${hm(t.qts)}</td></tr>`:''}${t.ctr?`<tr><th>Counter</th><td>${(ct(t.ctr)||{}).name}</td></tr>`:''}</table></div>
${['Booked','Waiting'].includes(t.st)?`<p><button class=dg data-a=cancel data-v=${t.id}>Cancel token</button></p>`:''}</div>`}
const so=(a,b)=>a==b?'selected':'';
function cust(){
 const e=est(wq(D.svc).length+serving(D.svc),D.svc),sl=slots(D.svc),mt=mine&&tk(mine),nl=S.notes.filter(n=>!n.t||S.my.includes(n.t)).slice(0,8);
 const sb=S.svc.map(v=>{const s=S.tok.filter(t=>t.svc==v.id&&t.st=='Serving').map(t=>`${t.id} at ${(ct(t.ctr)||{}).name}`);return `<div class="c st"><span>${v.name}</span><b style="font-size:15px">${s.join(', ')||'No one yet'}</b><span>${wq(v.id).length} waiting, avg ${v.avg} min</span></div>`}).join('');
 return `<div class=g><div class=c><h2>Register for a service</h2><form data-f=reg novalidate>
<label>Full name</label><input name=name value="${E(D.name)}" autocomplete=off>
<label>Mobile number (demo, no SMS is sent)</label><input name=ph inputmode=numeric value="${E(D.ph)}">
<label>Service</label><select name=svc data-r=1>${S.svc.map(x=>`<option value=${x.id} ${so(x.id,D.svc)}>${x.name} (avg ${x.avg} min)</option>`).join('')}</select>
<p class=m>${wq(D.svc).length} waiting, ${openC(D.svc).length} open counter(s). Joining now: ${e==null?'estimate unavailable, no counter is open for this service':'about '+e+' min (estimate)'}.</p>
<label>Priority</label><select name=pri data-r=1><option value=GEN ${so('GEN',D.pri)}>General</option><option value=ACC ${so('ACC',D.pri)}>Accessibility Assistance (verification required)</option></select>
${D.pri=='ACC'?`<label>Staff verification code</label><input name=code value="${E(D.code)}" autocomplete=off>`:''}
<label>Booking</label><select name=slot><option value="">Join the queue now</option>${sl.map(s=>`<option value=${s.ts} ${so(s.ts,D.slot)} ${s.left<1?'disabled':''}>Appointment at ${hm(s.ts)} (${Math.max(0,s.left)} left)</option>`).join('')}</select>
${D.err?`<p class=er>${E(D.err)}</p>`:''}<p><button class=pb>Get token</button></p></form></div>
<div class=c><h2>Track your token</h2><div class=r><input id=q placeholder="e.g. QS-CS-021" style="flex:1;min-width:140px"><button class=pb data-a=find>Find token</button></div>
<p class=r>${S.my.length?'<span class=m>Your tokens:</span>'+S.my.map(i=>`<button data-a=pick data-v=${i}>${i}</button>`).join(''):'<span class=m>Tokens you register appear here so you can reopen them.</span>'}</p>${mt?card(mt):''}</div></div>
<div class=c><h2>Now serving</h2><div class=g style="--w:200px">${sb}</div></div>
<div class=g><div class=c><h2>Live queue</h2>${tbl(0)}</div><div class=c><h2>Notifications</h2>${nl.length?`<ul class=nl>${nl.map(n=>`<li><span class=m>${hm(n.ts)}</span> ${E(n.m)}</li>`).join('')}</ul>`:'<p class=m>Messages about your tokens appear here.</p>'}</div></div>
<p class=m>Waiting times are baseline estimates: people ahead (including anyone being served) × service duration ÷ open counters, rounded up. They change as the queue changes and are not guaranteed.</p>`}
const cd=c=>{const t=c.tok&&tk(c.tok);return `<div class=c style="padding:10px"><div class=r><b>${E(c.name)}</b>${bd(!c.open?'Closed':t?'Serving':'Idle')}</div><select data-cs=${c.id}>${S.svc.map(x=>`<option value=${x.id} ${so(x.id,c.svc)}>${x.name}</option>`).join('')}</select><p class=m>${t?'Serving '+t.id:c.open?'Idle, ready for a token':'Closed, not counted in capacity'}</p><div class=r><button data-a=tog data-v=${c.id}>${c.open?'Close':'Open'}</button><button data-a=call data-v=${c.id} ${c.open&&!c.tok?'':'disabled'}>Call next</button><button data-a=done data-v=${c.id} ${t?'':'disabled'}>Complete</button></div></div>`};
function admin(){
 const R=ins(),ws=S.tok.filter(t=>t.start),av=ws.length>=3?Math.round(ws.reduce((a,t)=>a+t.start-t.qts,0)/ws.length/M)+' min':'n/a',op=S.ctr.filter(c=>c.open),bz=op.filter(c=>c.tok).length,
 by=[...R].sort((a,b)=>b.wl-a.wl),mx=f=>R.reduce((a,b)=>f(b)>f(a)?b:a),cn=s=>S.tok.filter(t=>t.st==s).length,
 sc=[['Total registered',S.tok.length],['Customers waiting',cn('Waiting')],['Currently serving',cn('Serving')],['Completed services',cn('Completed')],['Active counters',op.length+' of '+S.ctr.length],['Avg actual wait',av]],
 al=R.filter(r=>r.L).map(r=>`<div class="al a${r.L}"><b>${r.v.name}: ${LN[r.L]}</b><br>${r.w} waiting, ${r.oc} open counter(s), avg ${r.v.avg} min, workload ${r.wl} min.<br><span class=m>Rule: ${r.w} waiting is above ${S.th[r.L-1]}, the ${LN[r.L]} threshold.</span><br>Suggested: ${reco(r).t}</div>`).join('')||'<p class=m>All queues are within the Normal range.</p>',
 rc=R.filter(r=>r.L||(r.w&&!r.oc)).map(r=>{const o=reco(r);return `<div class=al style="border-color:var(--pr);background:color-mix(in srgb,var(--pr) 8%,transparent)"><b>${o.t}</b><br><span class=m>Why: ${o.why}</span>${o.ap?`<br><button class=pb data-a=apply data-v="${o.ap.join('|')}">Apply</button>`:''}${o.call?`<br><button class=pb data-a=call data-v=${o.call}>Call next</button>`:''}</div>`}).join('')||'<p class=m>No change needed: keep the current counter allocation.</p>',
 dm=mx(r=>r.dm),lg=mx(r=>r.lw==null?-1:r.lw),
 pt=[['Highest demand',`${dm.v.name} (${dm.dm} tokens)`],['Highest workload',by[0].wl?`${by[0].v.name} (${by[0].wl} min)`:'None'],['Longest estimated wait',lg.lw==null?'None available':`${lg.v.name} (~${lg.lw} min for a new arrival)`],['Completed services',cn('Completed')],['Counter utilisation',`${bz} of ${op.length} open counters busy`],['Queues over threshold',R.filter(r=>r.L).map(r=>r.v.name).join(', ')||'None']],
 rs=k=>`<select name=r${k}>${[1,2,3].map(n=>`<option ${so(S.rank[k],n)}>${n}</option>`).join('')}</select>`,
 ni=(n,l,v,x='')=>`<div><label>${l}</label><input name=${n} type=number value=${v} ${x}></div>`;
 return `<p class="al"><b>Demo staff access.</b> This role switch is for demonstration only, not real authentication. Data is stored in this browser (localStorage) and does not sync across devices.</p>
<div class=g style="--w:150px">${sc.map(([l,v])=>`<div class="c st"><span>${l}</span><b>${v}</b></div>`).join('')}</div>
<div class=c><div class=r><button class=pb data-a=next>Call next token</button><button data-a=clock>Advance demo clock +30 min</button><button class=dg data-a=reset>Reset demo data</button><span class=m>Demo clock ${hm(now())}${S.skew?` (+${S.skew/M} min)`:''}. Call next picks the best-ranked waiting token that an idle counter can serve.</span></div></div>
<div class=c><h2>Counters</h2><div class=g style="--w:230px">${S.ctr.map(cd).join('')}</div>
<form data-f=add class=r style="margin-top:12px"><input name=n placeholder="New counter name" style="flex:1;min-width:140px"><select name=v style="width:auto">${S.svc.map(x=>`<option value=${x.id}>${x.name}</option>`).join('')}</select><button class=pb>Add counter</button></form></div>
<div class=g><div class=c><h2>Overcrowding alerts</h2>${al}<h2 style="margin-top:12px">Counter recommendations</h2>${rc}<p class=m>Rule-based insights from live queue data. No trained AI model is used.</p></div>
<div class=c><h2>Workload ranking</h2><div class=tw><table><tr><th>Rank</th><th>Service</th><th>Waiting</th><th>Open counters</th><th>Workload (min)</th><th>Level</th></tr>${by.map((r,i)=>`<tr><td>${i+1}</td><td>${r.v.name}</td><td>${r.w}</td><td>${r.oc}</td><td>${r.wl}</td><td>${bd(LN[r.L])}</td></tr>`).join('')}</table></div><p class=m>Workload = waiting customers × average service duration. A rough demand indicator, not a wait time.</p>
<h2 style="margin-top:12px">Service patterns</h2><table>${pt.map(([a,b])=>`<tr><th>${a}</th><td style="white-space:normal">${b}</td></tr>`).join('')}</table></div></div>
<div class=c><h2>Active tokens and appointments</h2>${tbl(1)}</div>
<div class=g><div class=c><h2>Priority policy and settings</h2><ol>${Object.keys(S.rank).sort((a,b)=>S.rank[a]-S.rank[b]).map(k=>`<li>${PN[k]}</li>`).join('')}</ol><p class=m>Lowest rank number is called first, then first come first served within a rank. Eligible Appointment priority is granted automatically ${S.win} min before the booked time. Accessibility Assistance needs a staff verification code. Demo code: <b>${S.code}</b>.</p>
<form data-f=cfg><div class=g style="--w:120px">${ni('t0','Moderate above',S.th[0])}${ni('t1','High above',S.th[1])}${ni('t2','Critical above',S.th[2])}<div><label>Rank: Accessibility</label>${rs('ACC')}</div><div><label>Rank: Appointment</label>${rs('APT')}</div><div><label>Rank: General</label>${rs('GEN')}</div>${ni('cap','Bookings per slot',S.cap,'min=1 max=10')}${ni('win','Window (min before)',S.win,'min=0 max=120')}</div><p><button class=pb>Save settings</button></p></form></div>
<div class=c><h2>Notification log</h2>${S.notes.length?`<ul class=nl>${S.notes.slice(0,10).map(n=>`<li><span class=m>${hm(n.ts)}</span> ${E(n.m)}</li>`).join('')}</ul>`:'<p class=m>Events such as calls, completions and delays appear here.</p>'}</div></div>`}
function render(){$('#app').innerHTML=view=='c'?cust():admin();document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.v==view))}
/* ---------- events ---------- */
const A={tab:v=>{view=v;render()},
find:()=>{const q=((($('#q')||{}).value)||'').trim().toUpperCase(),t=tk(q);if(!t)return fail(`No token found for ${q||'an empty entry'}. Check the number and try again.`);mine=t.id;render()},
pick:v=>{mine=v;render()},
cancel:v=>{const t=tk(v);if(!t||!['Booked','Waiting'].includes(t.st))return fail('Only booked or waiting tokens can be cancelled.');t.st='Cancelled';note(`${t.id} was cancelled`,'cn:'+t.id,t.id);refresh()},
next:()=>callNext(),call:v=>callNext(v),done:v=>complete(v),tog:v=>tog(v),
apply:v=>{const[a,b,c]=v.split('|');cset(a,b,+c)},
clock:()=>{S.skew+=30*M;note('Demo clock advanced by 30 minutes',0);refresh()},
reset:()=>{S=seed();mine=null;D={svc:'CS',pri:'GEN',slot:''};Q=1;refresh();Q=0;toast('Demo data restored')}};
document.onclick=e=>{const b=e.target.closest('[data-a]');if(b&&!b.disabled)A[b.dataset.a](b.dataset.v)};
document.oninput=e=>{const x=e.target;if(x.form&&x.form.dataset.f=='reg'){D[x.name]=x.value;D.err=''}};
document.onchange=e=>{const x=e.target;if(x.dataset.r)render();if(x.dataset.cs&&cset(x.dataset.cs,x.value)===false)render()};
document.onkeydown=e=>{if(e.key=='Enter'&&e.target.id=='q'){e.preventDefault();A.find()}};
document.onsubmit=e=>{e.preventDefault();const f=e.target.dataset.f,d=new FormData(e.target);if(f=='reg'){for(const[k,v]of d)D[k]=v;reg()}else if(f=='cfg')cfg(d);else if(f=='add')addC(d.get('n'),d.get('v'))};
S=load();Q=1;refresh();Q=0;setInterval(()=>refresh(1),15000);
