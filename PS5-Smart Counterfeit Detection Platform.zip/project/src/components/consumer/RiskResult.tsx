import {
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RotateCcw,
  Flag,
  ArrowRight,
  ShieldCheck,
  ShieldAlert,
  ShieldX,
  TrendingUp,
  TrendingDown,
  Minus,
  Info,
  Clock,
  MapPin,
  Activity,
  Eye,
  Type,
  AlignLeft,
  Palette,
  Camera,
} from 'lucide-react';
import { useStore } from '@/store/useStore';
import type { RiskLevel, RiskFactor, VisualCheckItem } from '@/types';
import { RISK_LEVEL_LABELS } from '@/lib/riskAssessment';

const levelConfig: Record<
  RiskLevel,
  {
    icon: typeof CheckCircle2;
    shield: typeof ShieldCheck;
    color: string;
    bg: string;
    border: string;
    ring: string;
    bar: string;
    desc: string;
  }
> = {
  Genuine: {
    icon: CheckCircle2,
    shield: ShieldCheck,
    color: 'text-emerald-600',
    bg: 'bg-emerald-50',
    border: 'border-emerald-200',
    ring: 'ring-emerald-200',
    bar: 'bg-emerald-500',
    desc: 'This product matches our authorized database records. The batch number, validity period, and scan frequency all check out.',
  },
  Suspicious: {
    icon: AlertTriangle,
    shield: ShieldAlert,
    color: 'text-amber-600',
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    ring: 'ring-amber-200',
    bar: 'bg-amber-500',
    desc: 'This product shows warning signs. The code may have been scanned multiple times or from multiple locations, suggesting possible code reuse. We recommend further verification.',
  },
  Counterfeit: {
    icon: XCircle,
    shield: ShieldX,
    color: 'text-rose-600',
    bg: 'bg-rose-50',
    border: 'border-rose-200',
    ring: 'ring-rose-200',
    bar: 'bg-rose-500',
    desc: 'This product does not match our authorized database records, or the batch is expired or blacklisted. Do not use this product and consider reporting it.',
  },
};

const factorConfig: Record<
  RiskFactor['impact'],
  { icon: typeof TrendingUp; color: string; bg: string; label: string }
> = {
  positive: { icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'Positive' },
  warning: { icon: Minus, color: 'text-amber-600', bg: 'bg-amber-50', label: 'Warning' },
  negative: { icon: TrendingDown, color: 'text-rose-600', bg: 'bg-rose-50', label: 'Risk Factor' },
};

export function RiskResult() {
  const assessment = useStore((s) => s.lastRiskAssessment);
  const setConsumerTab = useStore((s) => s.setConsumerTab);
  const setView = useStore((s) => s.setView);

  if (!assessment) {
    return (
      <div className="card flex flex-col items-center justify-center py-16 text-center">
        <XCircle size={40} className="text-slate-300" />
        <p className="mt-4 text-sm text-slate-500">No verification result yet.</p>
        <button onClick={() => setConsumerTab('verify')} className="btn-primary mt-4">
          Go to Verification
        </button>
      </div>
    );
  }

  const config = levelConfig[assessment.level];
  const Icon = config.icon;
  const Shield = config.shield;

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      {/* Main result banner */}
      <div className={`card overflow-hidden ring-2 ${config.ring} animate-slide-up`}>
        <div className={`${config.bg} flex flex-col items-center px-6 py-8 text-center`}>
          <div className={`flex h-18 w-18 items-center justify-center rounded-full bg-white shadow-md ${config.color}`} style={{ width: '72px', height: '72px' }}>
            <Shield size={36} />
          </div>
          <h2 className={`mt-4 text-lg font-bold ${config.color}`}>
            {RISK_LEVEL_LABELS[assessment.level]}
          </h2>
          <p className="mt-1.5 max-w-md text-sm text-slate-600">{config.desc}</p>

          {/* Risk score bar */}
          <div className="mt-5 w-full max-w-sm">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-medium text-slate-500">Risk Score</span>
              <span className={`font-bold ${config.color}`}>{assessment.score}/100</span>
            </div>
            <div className="h-2.5 rounded-full bg-white/60 overflow-hidden">
              <div
                className={`h-full rounded-full ${config.bar} transition-all duration-700`}
                style={{ width: `${assessment.score}%` }}
              />
            </div>
            <p className="mt-1 text-xs text-slate-400">Higher score = higher confidence in authenticity</p>
          </div>
        </div>

        {/* Matched product details */}
        {assessment.matchedProduct && (
          <div className="grid gap-6 p-6 sm:grid-cols-2 border-b border-slate-100">
            <div className="flex items-start gap-4">
              <img
                src={assessment.matchedProduct.referenceImageUrl}
                alt={assessment.matchedProduct.name}
                className="h-24 w-24 rounded-lg object-cover"
              />
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-slate-800">{assessment.matchedProduct.name}</h3>
                <p className="text-xs text-slate-500">{assessment.matchedProduct.brand}</p>
                <p className="mt-1 text-xs text-slate-400">{assessment.matchedProduct.category}</p>
                <div className="mt-2 flex items-center gap-1.5">
                  <Icon size={14} className={config.color} />
                  <span className={`text-xs font-semibold ${config.color}`}>{RISK_LEVEL_LABELS[assessment.level]}</span>
                </div>
              </div>
            </div>

            <div className="space-y-2.5">
              <DetailRow label="Batch Number" value={assessment.matchedProduct.batchNumber} />
              <DetailRow label="Authorized Distributor" value={assessment.matchedProduct.authorizedDistributor} />
              <DetailRow label="Manufacture Date" value={assessment.matchedProduct.manufactureDate} />
              <DetailRow label="Expiry Date" value={assessment.matchedProduct.expiryDate} />
            </div>
          </div>
        )}

        {/* Explainable risk breakdown */}
        <div className="p-6">
          <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
            <Activity size={16} className="text-brand-600" />
            Why This Risk Level?
          </h3>
          <div className="space-y-3">
            {assessment.factors.map((factor, idx) => {
              const fc = factorConfig[factor.impact];
              const FactorIcon = fc.icon;
              return (
                <div
                  key={idx}
                  className={`flex items-start gap-3 rounded-lg border ${factor.impact === 'negative' ? 'border-rose-200' : factor.impact === 'warning' ? 'border-amber-200' : 'border-emerald-200'} ${fc.bg} p-3.5`}
                >
                  <div className={`flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg bg-white ${fc.color}`}>
                    <FactorIcon size={15} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-700">{factor.label}</p>
                    <p className="mt-0.5 text-xs text-slate-500 leading-relaxed">{factor.detail}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Visual analysis breakdown */}
          {assessment.visualAnalysis && (
            <VisualAnalysisSection visual={assessment.visualAnalysis} />
          )}

          {/* Quick stats */}
          <div className="mt-5 grid grid-cols-3 gap-3">
            <StatChip icon={Activity} label="Scan Frequency" value={`${assessment.scanFrequency}× / 24h`} />
            <StatChip icon={MapPin} label="Unique Locations" value={String(assessment.uniqueLocations)} />
            <StatChip icon={Clock} label="Checked At" value={new Date(assessment.timestamp).toLocaleTimeString()} />
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-3 border-t border-slate-100 p-6 sm:flex-row">
          <button onClick={() => setConsumerTab('verify')} className="btn-secondary flex-1">
            <RotateCcw size={16} />
            Verify Another Product
          </button>
          {assessment.level !== 'Genuine' && (
            <button onClick={() => setView('reporting')} className="btn-danger flex-1">
              <Flag size={16} />
              Report This Product
            </button>
          )}
          <button onClick={() => setConsumerTab('history')} className="btn-ghost flex-1">
            View History
            <ArrowRight size={16} />
          </button>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="flex items-start gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4">
        <Info size={18} className="mt-0.5 flex-shrink-0 text-slate-400" />
        <p className="text-xs text-slate-500">
          Note: Barcodes and QR codes can be copied. Automated risk scores and image
          comparisons cannot provide definitive proof of authenticity. Always purchase
          from authorized distributors and retain proof of purchase.
        </p>
      </div>
    </div>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-xs">
      <span className="text-slate-400">{label}</span>
      <span className="font-medium text-slate-700 text-right">{value}</span>
    </div>
  );
}

function StatChip({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Activity;
  label: string;
  value: string;
}) {
  return (
    <div className="flex flex-col items-center rounded-lg bg-slate-50 p-3 text-center">
      <Icon size={16} className="text-slate-400 mb-1" />
      <p className="text-sm font-bold text-slate-700">{value}</p>
      <p className="text-[10px] text-slate-400">{label}</p>
    </div>
  );
}

const checkIcons = [Type, Type, AlignLeft, Palette];

function VisualAnalysisSection({ visual }: { visual: import('@/types').VisualAnalysis }) {
  const matchColor =
    visual.matchScore >= 85
      ? 'text-emerald-600'
      : visual.matchScore >= 60
      ? 'text-amber-600'
      : 'text-rose-600';
  const matchBg =
    visual.matchScore >= 85
      ? 'bg-emerald-50'
      : visual.matchScore >= 60
      ? 'bg-amber-50'
      : 'bg-rose-50';
  const matchBar =
    visual.matchScore >= 85
      ? 'bg-emerald-500'
      : visual.matchScore >= 60
      ? 'bg-amber-500'
      : 'bg-rose-500';

  return (
    <div className="mt-6 border-t border-slate-100 pt-5">
      <h4 className="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-700">
        <Eye size={16} className="text-brand-600" />
        Packaging Visual Analysis
      </h4>

      {/* Side-by-side images */}
      <div className="mb-4 grid grid-cols-2 gap-3">
        <div className="relative overflow-hidden rounded-lg">
          <img
            src={visual.userImageUrl ?? ''}
            alt="Your upload"
            className="h-36 w-full object-cover"
          />
          <span className="absolute bottom-1.5 left-1.5 rounded bg-slate-900/70 px-2 py-0.5 text-[10px] font-semibold text-white">
            <Camera size={10} className="mr-1 inline" />
            Your Image
          </span>
        </div>
        <div className="relative overflow-hidden rounded-lg">
          <img
            src={visual.referenceImageUrl}
            alt="Reference"
            className="h-36 w-full object-cover"
          />
          <span className="absolute bottom-1.5 left-1.5 rounded bg-slate-900/70 px-2 py-0.5 text-[10px] font-semibold text-white">
            Reference
          </span>
        </div>
      </div>

      {/* Match score bar */}
      <div className={`rounded-lg ${matchBg} p-3`}>
        <div className="mb-1.5 flex items-center justify-between text-xs">
          <span className="font-medium text-slate-600">Visual Match Score</span>
          <span className={`font-bold ${matchColor}`}>{visual.matchScore}/100</span>
        </div>
        <div className="h-2 rounded-full bg-white/60 overflow-hidden">
          <div
            className={`h-full rounded-full ${matchBar} transition-all duration-700`}
            style={{ width: `${visual.matchScore}%` }}
          />
        </div>
        <p className="mt-1.5 text-xs text-slate-500">{visual.summary}</p>
      </div>

      {/* Diff checklist */}
      <div className="mt-3 space-y-2">
        {visual.checks.map((check, idx) => {
          const Icon = checkIcons[idx] ?? Type;
          const cfg = {
            pass: { color: 'text-emerald-600', bg: 'bg-emerald-50', icon: CheckCircle2 },
            warning: { color: 'text-amber-600', bg: 'bg-amber-50', icon: AlertTriangle },
            fail: { color: 'text-rose-600', bg: 'bg-rose-50', icon: XCircle },
          }[check.status];
          const StatusIcon = cfg.icon;
          return (
            <div key={idx} className="flex items-start gap-2.5 rounded-lg border border-slate-100 p-2.5">
              <div className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded ${cfg.bg} ${cfg.color}`}>
                <Icon size={13} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs font-semibold text-slate-600">{check.label}</p>
                  <span className={`flex items-center gap-0.5 text-[10px] font-semibold ${cfg.color}`}>
                    <StatusIcon size={10} />
                    {check.status === 'pass' ? 'Pass' : check.status === 'warning' ? 'Warning' : 'Fail'}
                  </span>
                </div>
                <p className="mt-0.5 text-[11px] text-slate-500 leading-relaxed">{check.detail}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
