import {
  History,
  ScanLine,
  Keyboard,
  Upload,
  MapPin,
  Clock,
  ShieldCheck,
  ShieldAlert,
  ShieldX,
  Trash2,
} from 'lucide-react';
import { useStore } from '@/store/useStore';
import type { RiskLevel } from '@/types';
import { RISK_LEVEL_LABELS } from '@/lib/riskAssessment';

const methodConfig = {
  scanner: { icon: ScanLine, label: 'Scanner' },
  manual: { icon: Keyboard, label: 'Manual' },
  upload: { icon: Upload, label: 'Upload' },
};

const levelColors: Record<RiskLevel, { icon: typeof ShieldCheck; color: string; bg: string }> = {
  Genuine: { icon: ShieldCheck, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  Suspicious: { icon: ShieldAlert, color: 'text-amber-600', bg: 'bg-amber-50' },
  Counterfeit: { icon: ShieldX, color: 'text-rose-600', bg: 'bg-rose-50' },
};

export function VerificationHistory() {
  const logs = useStore((s) => s.verificationLogs);
  const setConsumerTab = useStore((s) => s.setConsumerTab);

  // Show only entries created through the verification engine (have riskAssessment)
  const history = [...logs]
    .filter((l) => l.riskAssessment)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const genuineCount = history.filter((l) => l.status === 'Genuine').length;
  const suspiciousCount = history.filter((l) => l.status === 'Suspicious').length;
  const counterfeitCount = history.filter((l) => l.status === 'Counterfeit').length;

  return (
    <div className="space-y-5">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <HistoryStat count={genuineCount} label="Likely Genuine" color="text-emerald-600" bg="bg-emerald-50" />
        <HistoryStat count={suspiciousCount} label="Needs Verification" color="text-amber-600" bg="bg-amber-50" />
        <HistoryStat count={counterfeitCount} label="Potentially Counterfeit" color="text-rose-600" bg="bg-rose-50" />
      </div>

      {/* History list */}
      <div className="card overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <div className="flex items-center gap-2">
            <History size={18} className="text-brand-600" />
            <h3 className="text-sm font-semibold text-slate-700">Verification History</h3>
          </div>
          <span className="text-xs text-slate-400">{history.length} total checks</span>
        </div>

        {history.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <History size={32} className="text-slate-300" />
            <p className="mt-3 text-sm text-slate-500">No verification checks yet.</p>
            <button onClick={() => setConsumerTab('verify')} className="btn-primary mt-4">
              Verify a Product
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {history.map((log) => {
              const mc = methodConfig[log.method ?? 'scanner'];
              const MethodIcon = mc.icon;
              const lc = levelColors[log.status];
              const LevelIcon = lc.icon;
              const product = log.riskAssessment?.matchedProduct;

              return (
                <div key={log.id} className="flex items-start gap-4 px-5 py-4 transition-colors hover:bg-slate-50">
                  {/* Product image or status icon */}
                  {product ? (
                    <img
                      src={product.referenceImageUrl}
                      alt={product.name}
                      className="h-12 w-12 flex-shrink-0 rounded-lg object-cover"
                    />
                  ) : (
                    <div className={`flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg ${lc.bg}`}>
                      <LevelIcon size={20} className={lc.color} />
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-700 truncate">
                          {product ? product.name : 'Unknown Product'}
                        </p>
                        <p className="text-xs text-slate-400 truncate">
                          {product ? product.brand : log.query}
                        </p>
                      </div>
                      <div className="flex flex-shrink-0 items-center gap-1.5">
                        <LevelIcon size={14} className={lc.color} />
                        <span className={`text-xs font-semibold ${lc.color}`}>
                          {RISK_LEVEL_LABELS[log.status]}
                        </span>
                      </div>
                    </div>

                    <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <MethodIcon size={12} />
                        {mc.label}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock size={12} />
                        {new Date(log.timestamp).toLocaleString()}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin size={12} />
                        {log.location}
                      </span>
                      {log.riskAssessment && (
                        <span className="font-medium text-slate-500">
                          Score: {log.riskAssessment.score}/100
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function HistoryStat({ count, label, color, bg }: { count: number; label: string; color: string; bg: string }) {
  return (
    <div className={`card p-4 text-center ${bg} border-transparent`}>
      <p className={`text-2xl font-bold ${color}`}>{count}</p>
      <p className="mt-0.5 text-xs text-slate-500">{label}</p>
    </div>
  );
}
