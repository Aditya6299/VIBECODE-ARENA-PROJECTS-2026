import { ScanLine, FileCheck2, History, Upload } from 'lucide-react';
import { useStore } from '@/store/useStore';
import type { ConsumerTab } from '@/types';
import { VerificationEngine } from './VerificationEngine';
import { RiskResult } from './RiskResult';
import { VerificationHistory } from './VerificationHistory';
import { UploadTab } from './UploadTab';

const tabs: { id: ConsumerTab; label: string; icon: typeof ScanLine }[] = [
  { id: 'verify', label: 'Verify Product', icon: ScanLine },
  { id: 'result', label: 'Result', icon: FileCheck2 },
  { id: 'history', label: 'History', icon: History },
  { id: 'upload', label: 'Image Upload', icon: Upload },
];

export function ConsumerPortal() {
  const consumerTab = useStore((s) => s.consumerTab);
  const setConsumerTab = useStore((s) => s.setConsumerTab);
  const lastAssessment = useStore((s) => s.lastRiskAssessment);

  // Only show result tab if there's a result
  const visibleTabs = tabs.filter((t) => t.id !== 'result' || lastAssessment);

  return (
    <div className="space-y-6">
      {/* Tab bar */}
      <div className="flex gap-2 overflow-x-auto rounded-xl border border-slate-200 bg-white p-1.5 shadow-sm">
        {visibleTabs.map((tab) => {
          const Icon = tab.icon;
          const active = consumerTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setConsumerTab(tab.id)}
              className={`flex flex-shrink-0 items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-all ${
                active
                  ? 'bg-brand-600 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Icon size={16} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div className="animate-fade-in">
        {consumerTab === 'verify' && <VerificationEngine />}
        {consumerTab === 'result' && <RiskResult />}
        {consumerTab === 'history' && <VerificationHistory />}
        {consumerTab === 'upload' && <UploadTab />}
      </div>
    </div>
  );
}
