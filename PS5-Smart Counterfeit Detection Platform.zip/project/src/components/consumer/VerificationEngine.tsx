import { useState, useRef, useEffect } from 'react';
import {
  ScanLine,
  Keyboard,
  Camera,
  RefreshCw,
  MapPin,
  Upload,
  AlertTriangle,
  ChevronRight,
  PackageSearch,
} from 'lucide-react';
import { useStore } from '@/store/useStore';
import type { Product } from '@/types';

type InputMode = 'scanner' | 'manual';

export function VerificationEngine() {
  const products = useStore((s) => s.products);
  const verifyIdentifier = useStore((s) => s.verifyIdentifier);
  const setConsumerTab = useStore((s) => s.setConsumerTab);
  const pushToast = useStore((s) => s.pushToast);

  const [mode, setMode] = useState<InputMode>('scanner');
  const [scanning, setScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [manualQuery, setManualQuery] = useState('');
  const [location, setLocation] = useState('Auto-detected: Your Location');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Simulate camera scan progress
  useEffect(() => {
    if (!scanning) return;
    if (scanProgress >= 100) {
      const product = products.find((p) => p.id === selectedProductId);
      const query = product ? product.batchNumber : selectedProductId;
      setScanning(false);
      setScanProgress(0);
      verifyIdentifier(query, 'scanner', location);
      setConsumerTab('result');
      return;
    }
    const timer = setTimeout(() => setScanProgress((p) => p + 4), 50);
    return () => clearTimeout(timer);
  }, [scanning, scanProgress, selectedProductId, products, verifyIdentifier, setConsumerTab, location]);

  const handleStartScan = () => {
    if (!selectedProductId) {
      pushToast('Please select a product to scan', 'error');
      return;
    }
    setScanning(true);
    setScanProgress(0);
  };

  const handleFileScan = (file: File) => {
    if (!file.type.startsWith('image/')) {
      pushToast('Please upload an image file containing a QR/barcode', 'error');
      return;
    }
    if (!selectedProductId) {
      pushToast('Please select a product first, then upload a code image', 'error');
      return;
    }
    setScanning(true);
    setScanProgress(0);
  };

  const handleManualVerify = () => {
    if (!manualQuery.trim()) {
      pushToast('Please enter a Product ID or Batch Number', 'error');
      return;
    }
    verifyIdentifier(manualQuery, 'manual', location);
    setConsumerTab('result');
  };

  const selectedProduct = products.find((p: Product) => p.id === selectedProductId);

  return (
    <div className="space-y-5">
      {/* Dual input mode selector */}
      <div className="flex gap-2 rounded-xl border border-slate-200 bg-white p-1.5 shadow-sm">
        <ModeButton
          active={mode === 'scanner'}
          onClick={() => setMode('scanner')}
          icon={ScanLine}
          label="Scan QR / Barcode"
        />
        <ModeButton
          active={mode === 'manual'}
          onClick={() => setMode('manual')}
          icon={Keyboard}
          label="Manual ID Entry"
        />
      </div>

      {/* Scanner mode */}
      {mode === 'scanner' && (
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Scanner visual */}
          <div className="card overflow-hidden">
            <div className="relative flex h-80 items-center justify-center bg-gradient-to-br from-slate-900 via-brand-900 to-slate-800">
              <div className="relative h-56 w-56 rounded-2xl border-2 border-brand-400/50">
                <div className="absolute -top-1 -left-1 h-6 w-6 border-t-2 border-l-2 border-brand-400 rounded-tl-lg" />
                <div className="absolute -top-1 -right-1 h-6 w-6 border-t-2 border-r-2 border-brand-400 rounded-tr-lg" />
                <div className="absolute -bottom-1 -left-1 h-6 w-6 border-b-2 border-l-2 border-brand-400 rounded-bl-lg" />
                <div className="absolute -bottom-1 -right-1 h-6 w-6 border-b-2 border-r-2 border-brand-400 rounded-br-lg" />

                {scanning && (
                  <div className="absolute inset-x-2 h-0.5 bg-brand-400 shadow-[0_0_10px_2px_rgba(129,140,248,0.6)] animate-scan-line" />
                )}

                {selectedProduct ? (
                  <img
                    src={selectedProduct.referenceImageUrl}
                    alt={selectedProduct.name}
                    className="h-full w-full rounded-2xl object-cover opacity-80"
                  />
                ) : (
                  <div className="flex h-full w-full flex-col items-center justify-center text-brand-300/60">
                    <Camera size={40} />
                    <p className="mt-2 text-xs">Select a product to scan</p>
                  </div>
                )}
              </div>

              {scanning && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-brand-400/20">
                  <div
                    className="h-full bg-brand-400 transition-all duration-75"
                    style={{ width: `${scanProgress}%` }}
                  />
                </div>
              )}
            </div>

            <div className="p-4 space-y-2">
              {scanning ? (
                <div className="flex items-center justify-center gap-2 text-sm text-brand-600">
                  <RefreshCw size={16} className="animate-spin" />
                  Scanning... {scanProgress}%
                </div>
              ) : (
                <>
                  <button onClick={handleStartScan} className="btn-primary w-full">
                    <ScanLine size={18} />
                    Start Verification Scan
                  </button>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="btn-secondary w-full"
                  >
                    <Upload size={16} />
                    Upload Code Image
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileScan(file);
                    }}
                  />
                </>
              )}
            </div>
          </div>

          {/* Controls */}
          <div className="space-y-4">
            <div className="card p-5">
              <h3 className="text-sm font-semibold text-slate-700 mb-4">Scan Configuration</h3>
              <div className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-slate-500">
                    Select Product to Verify
                  </label>
                  <select
                    value={selectedProductId}
                    onChange={(e) => setSelectedProductId(e.target.value)}
                    className="input-field"
                  >
                    <option value="">Choose a product...</option>
                    {products.map((p: Product) => (
                      <option key={p.id} value={p.id}>
                        {p.brand} — {p.name} ({p.batchNumber})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-slate-500">
                    Scan Location
                  </label>
                  <div className="relative">
                    <MapPin size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="input-field pl-9"
                      placeholder="Where are you scanning this product?"
                    />
                  </div>
                </div>
              </div>

              {selectedProduct && (
                <div className="mt-5 rounded-lg bg-slate-50 p-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">
                    Product Preview
                  </p>
                  <div className="flex gap-3">
                    <img
                      src={selectedProduct.referenceImageUrl}
                      alt={selectedProduct.name}
                      className="h-16 w-16 rounded-lg object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-700 truncate">{selectedProduct.name}</p>
                      <p className="text-xs text-slate-500">{selectedProduct.brand}</p>
                      <p className="mt-1 text-xs text-slate-400">Batch: {selectedProduct.batchNumber}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Manual ID entry mode */}
      {mode === 'manual' && (
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="card p-6">
            <div className="flex items-center gap-2 mb-5">
              <Keyboard size={20} className="text-brand-600" />
              <h3 className="text-sm font-semibold text-slate-700">Enter Product Identifier</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-500">
                  Product ID or Batch Number <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <PackageSearch size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={manualQuery}
                    onChange={(e) => setManualQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleManualVerify()}
                    placeholder="e.g., p-001 or LA-2024-0847"
                    className="input-field pl-10 font-mono"
                  />
                </div>
                <p className="mt-1.5 text-xs text-slate-400">
                  Enter the product ID (e.g. p-001) or batch number (e.g. LA-2024-0847) printed on the packaging.
                </p>
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-500">
                  Your Location
                </label>
                <div className="relative">
                  <MapPin size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="input-field pl-9"
                  />
                </div>
              </div>

              <button onClick={handleManualVerify} disabled={!manualQuery.trim()} className="btn-primary w-full">
                <ScanLine size={18} />
                Verify Product
                <ChevronRight size={16} />
              </button>
            </div>
          </div>

          {/* Quick reference */}
          <div className="card p-5">
            <h3 className="text-sm font-semibold text-slate-700 mb-3">Quick Reference</h3>
            <p className="text-xs text-slate-500 mb-3">
              Here are some sample identifiers from the database you can try:
            </p>
            <div className="space-y-2">
              {products.slice(0, 4).map((p: Product) => (
                <button
                  key={p.id}
                  onClick={() => setManualQuery(p.batchNumber)}
                  className="flex w-full items-center justify-between rounded-lg border border-slate-200 px-3 py-2.5 text-left transition-colors hover:border-brand-300 hover:bg-brand-50/50"
                >
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-600 truncate">{p.name}</p>
                    <p className="text-xs text-slate-400">{p.brand}</p>
                  </div>
                  <code className="flex-shrink-0 rounded bg-slate-100 px-2 py-0.5 text-xs font-mono text-slate-600">
                    {p.batchNumber}
                  </code>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Mandatory disclaimer banner */}
      <div className="flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4">
        <AlertTriangle size={20} className="mt-0.5 flex-shrink-0 text-amber-600" />
        <div>
          <p className="text-sm font-semibold text-amber-800">Important Disclaimer</p>
          <p className="mt-0.5 text-sm text-amber-700">
            Note: Barcodes and QR codes can be copied. Automated risk scores and
            image comparisons cannot provide definitive proof of authenticity.
            Always purchase from authorized distributors and retain proof of purchase.
          </p>
        </div>
      </div>
    </div>
  );
}

function ModeButton({
  active,
  onClick,
  icon: Icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: typeof ScanLine;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-1 items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-all ${
        active ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
      }`}
    >
      <Icon size={16} />
      {label}
    </button>
  );
}
