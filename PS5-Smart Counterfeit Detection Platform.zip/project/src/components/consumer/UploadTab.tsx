import { useState, useRef, useEffect } from 'react';
import {
  Upload,
  ImageIcon,
  X,
  ScanLine,
  AlertTriangle,
  Camera,
  Check,
  RefreshCw,
  Eye,
  Type,
  AlignLeft,
  Palette,
  ChevronRight,
} from 'lucide-react';
import { useStore } from '@/store/useStore';
import type { Product, VisualAnalysis, VisualCheckItem } from '@/types';
import { simulateVisualAnalysis } from '@/lib/visualAnalysis';

type Phase = 'idle' | 'analyzing' | 'results';

export function UploadTab() {
  const products = useStore((s) => s.products);
  const verifyIdentifier = useStore((s) => s.verifyIdentifier);
  const setConsumerTab = useStore((s) => s.setConsumerTab);
  const pushToast = useStore((s) => s.pushToast);

  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [phase, setPhase] = useState<Phase>('idle');
  const [scanProgress, setScanProgress] = useState(0);
  const [visualResult, setVisualResult] = useState<VisualAnalysis | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedProduct = products.find((p: Product) => p.id === selectedProductId);

  // Simulated scanning animation
  useEffect(() => {
    if (phase !== 'analyzing') return;
    if (scanProgress >= 100) {
      // Generate visual analysis result
      const result = simulateVisualAnalysis(
        selectedProduct ?? null,
        previewUrl,
        selectedProduct?.referenceImageUrl ?? ''
      );
      setVisualResult(result);
      setPhase('results');
      setScanProgress(0);
      return;
    }
    const timer = setTimeout(() => setScanProgress((p) => p + 3), 60);
    return () => clearTimeout(timer);
  }, [phase, scanProgress, selectedProduct, previewUrl]);

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      pushToast('Please upload an image file', 'error');
      return;
    }
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    setPhase('idle');
    setVisualResult(null);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const handleStartAnalysis = () => {
    if (!previewUrl) {
      pushToast('Please upload a product image first', 'error');
      return;
    }
    if (!selectedProductId) {
      pushToast('Please select a product to compare against', 'error');
      return;
    }
    setPhase('analyzing');
    setScanProgress(0);
  };

  const handleProceedToVerification = () => {
    if (!selectedProduct || !visualResult) return;
    verifyIdentifier(
      selectedProduct.batchNumber,
      'upload',
      'Image upload verification',
      visualResult
    );
    setConsumerTab('result');
  };

  const handleReset = () => {
    setPreviewUrl(null);
    setPhase('idle');
    setVisualResult(null);
    setScanProgress(0);
  };

  return (
    <div className="space-y-5">
      {/* Step 1: Upload + product selection */}
      {phase === 'idle' && (
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Upload zone */}
          <div className="card p-5">
            <div className="mb-4 flex items-center gap-2">
              <Camera size={18} className="text-brand-600" />
              <h3 className="text-sm font-semibold text-slate-700">Upload or Capture Packaging</h3>
            </div>

            {!previewUrl ? (
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 py-16 transition-colors hover:border-brand-400 hover:bg-brand-50/50"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-brand-100 text-brand-600">
                  <Upload size={24} />
                </div>
                <p className="mt-4 text-sm font-medium text-slate-600">
                  Drop image here or click to browse
                </p>
                <p className="mt-1 text-xs text-slate-400">
                  Upload a clear photo of the product packaging (logo, label, spelling)
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFile(file);
                  }}
                />
              </div>
            ) : (
              <div className="relative">
                <img
                  src={previewUrl}
                  alt="Uploaded packaging"
                  className="w-full rounded-xl object-cover"
                  style={{ maxHeight: '300px' }}
                />
                <button
                  onClick={() => setPreviewUrl(null)}
                  className="absolute top-3 right-3 rounded-lg bg-slate-900/60 p-1.5 text-white transition-colors hover:bg-slate-900/80"
                >
                  <X size={16} />
                </button>
                <div className="mt-3 flex items-center gap-2 text-sm text-emerald-600">
                  <ImageIcon size={16} />
                  <span>Image ready for analysis</span>
                </div>
              </div>
            )}
          </div>

          {/* Product selection */}
          <div className="space-y-4">
            <div className="card p-5">
              <div className="mb-4 flex items-center gap-2">
                <Eye size={18} className="text-brand-600" />
                <h3 className="text-sm font-semibold text-slate-700">Select Reference Product</h3>
              </div>

              <label className="mb-1.5 block text-xs font-medium text-slate-500">
                Choose product to compare against
              </label>
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="input-field"
              >
                <option value="">Choose a product...</option>
                {products.map((p: Product) => (
                  <option key={p.id} value={p.id}>
                    {p.brand} — {p.name}
                  </option>
                ))}
              </select>

              {selectedProduct && (
                <div className="mt-4 rounded-lg bg-slate-50 p-3">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Reference Image
                  </p>
                  <img
                    src={selectedProduct.referenceImageUrl}
                    alt={selectedProduct.name}
                    className="h-32 w-full rounded-lg object-cover"
                  />
                  <p className="mt-2 text-xs text-slate-500">
                    {selectedProduct.brand} — {selectedProduct.name}
                  </p>
                </div>
              )}

              <button
                onClick={handleStartAnalysis}
                disabled={!previewUrl || !selectedProductId}
                className="btn-primary mt-5 w-full"
              >
                <ScanLine size={18} />
                Start Visual Analysis
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Step 2: Analyzing animation */}
      {phase === 'analyzing' && (
        <div className="card overflow-hidden">
          <div className="flex flex-col items-center px-6 py-10">
            <h3 className="mb-6 text-base font-semibold text-slate-700">
              Analyzing Packaging Details...
            </h3>

            {/* Side-by-side with scanning overlay */}
            <div className="grid w-full max-w-2xl grid-cols-2 gap-4">
              {/* User image */}
              <div className="relative overflow-hidden rounded-xl">
                <img
                  src={previewUrl ?? ''}
                  alt="Your upload"
                  className="h-48 w-full object-cover"
                />
                <div className="absolute inset-0 bg-brand-900/20" />
                {/* Scanning line */}
                <div
                  className="absolute inset-x-0 h-1 bg-brand-400 shadow-[0_0_12px_3px_rgba(129,140,248,0.7)] transition-all duration-75"
                  style={{ top: `${scanProgress}%` }}
                />
                <span className="absolute bottom-2 left-2 rounded bg-slate-900/70 px-2 py-0.5 text-xs font-medium text-white">
                  Your Image
                </span>
              </div>

              {/* Reference image */}
              <div className="relative overflow-hidden rounded-xl">
                <img
                  src={selectedProduct?.referenceImageUrl ?? ''}
                  alt="Reference"
                  className="h-48 w-full object-cover"
                />
                <div className="absolute inset-0 bg-brand-900/20" />
                <div
                  className="absolute inset-x-0 h-1 bg-brand-400 shadow-[0_0_12px_3px_rgba(129,140,248,0.7)] transition-all duration-75"
                  style={{ top: `${scanProgress}%` }}
                />
                <span className="absolute bottom-2 left-2 rounded bg-slate-900/70 px-2 py-0.5 text-xs font-medium text-white">
                  Reference
                </span>
              </div>
            </div>

            {/* Progress bar */}
            <div className="mt-6 w-full max-w-md">
              <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full rounded-full bg-brand-500 transition-all duration-75"
                  style={{ width: `${scanProgress}%` }}
                />
              </div>
              <div className="mt-2 flex items-center justify-center gap-2 text-sm text-brand-600">
                <RefreshCw size={14} className="animate-spin" />
                Comparing visual features... {scanProgress}%
              </div>
            </div>

            {/* Step labels */}
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              {[
                { label: 'Logo Typography', icon: Type },
                { label: 'Spelling Check', icon: Type },
                { label: 'Label Alignment', icon: AlignLeft },
                { label: 'Color Saturation', icon: Palette },
              ].map((step, i) => {
                const stepProgress = (i + 1) * 25;
                const done = scanProgress >= stepProgress;
                const StepIcon = step.icon;
                return (
                  <span
                    key={step.label}
                    className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium transition-colors ${
                      done
                        ? 'bg-emerald-50 text-emerald-600'
                        : 'bg-slate-100 text-slate-400'
                    }`}
                  >
                    {done ? <Check size={12} /> : <StepIcon size={12} />}
                    {step.label}
                  </span>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Step 3: Results — side-by-side comparison + diff checklist */}
      {phase === 'results' && visualResult && (
        <div className="space-y-5">
          {/* Side-by-side comparison */}
          <div className="card overflow-hidden">
            <div className="border-b border-slate-100 px-5 py-4">
              <div className="flex items-center gap-2">
                <Eye size={18} className="text-brand-600" />
                <h3 className="text-sm font-semibold text-slate-700">Side-by-Side Comparison</h3>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-px bg-slate-200">
              <div className="relative bg-white">
                <img
                  src={visualResult.userImageUrl ?? previewUrl ?? ''}
                  alt="Your upload"
                  className="h-56 w-full object-cover"
                />
                <span className="absolute bottom-2 left-2 rounded bg-slate-900/70 px-2.5 py-1 text-xs font-semibold text-white">
                  Your Image
                </span>
              </div>
              <div className="relative bg-white">
                <img
                  src={visualResult.referenceImageUrl}
                  alt="Reference"
                  className="h-56 w-full object-cover"
                />
                <span className="absolute bottom-2 left-2 rounded bg-slate-900/70 px-2.5 py-1 text-xs font-semibold text-white">
                  Database Reference
                </span>
              </div>
            </div>
          </div>

          {/* Visual match score banner */}
          <div
            className={`card overflow-hidden ring-2 ${
              visualResult.matchScore >= 85
                ? 'ring-emerald-200'
                : visualResult.matchScore >= 60
                ? 'ring-amber-200'
                : 'ring-rose-200'
            }`}
          >
            <div
              className={`flex items-center gap-4 px-6 py-5 ${
                visualResult.matchScore >= 85
                  ? 'bg-emerald-50'
                  : visualResult.matchScore >= 60
                  ? 'bg-amber-50'
                  : 'bg-rose-50'
              }`}
            >
              <div
                className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-xl bg-white shadow-sm ${
                  visualResult.matchScore >= 85
                    ? 'text-emerald-600'
                    : visualResult.matchScore >= 60
                    ? 'text-amber-600'
                    : 'text-rose-600'
                }`}
              >
                <span className="text-lg font-bold">{visualResult.matchScore}%</span>
              </div>
              <div className="min-w-0">
                <p
                  className={`text-sm font-bold ${
                    visualResult.matchScore >= 85
                      ? 'text-emerald-700'
                      : visualResult.matchScore >= 60
                      ? 'text-amber-700'
                      : 'text-rose-700'
                  }`}
                >
                  {visualResult.matchScore >= 85
                    ? 'High Visual Match'
                    : visualResult.matchScore >= 60
                    ? 'Partial Visual Match'
                    : 'Low Visual Match'}
                </p>
                <p className="mt-0.5 text-sm text-slate-600">{visualResult.summary}</p>
              </div>
            </div>

            {/* Visual diff checklist */}
            <div className="divide-y divide-slate-100">
              {visualResult.checks.map((check, idx) => (
                <VisualCheckRow key={idx} check={check} index={idx} />
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-3 sm:flex-row">
            <button onClick={handleReset} className="btn-secondary flex-1">
              <RefreshCw size={16} />
              Analyze Another Image
            </button>
            <button onClick={handleProceedToVerification} className="btn-primary flex-1">
              <ScanLine size={18} />
              Proceed to Risk Assessment
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div className="flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4">
        <AlertTriangle size={20} className="mt-0.5 flex-shrink-0 text-amber-600" />
        <div>
          <p className="text-sm font-semibold text-amber-800">Important Disclaimer</p>
          <p className="mt-0.5 text-sm text-amber-700">
            Note: Barcodes and QR codes can be copied. Automated risk scores and
            image comparisons cannot provide definitive proof of authenticity.
          </p>
        </div>
      </div>
    </div>
  );
}

const checkIcons = [Type, Type, AlignLeft, Palette];

function VisualCheckRow({ check, index }: { check: VisualCheckItem; index: number }) {
  const Icon = checkIcons[index] ?? Type;
  const config = {
    pass: { color: 'text-emerald-600', bg: 'bg-emerald-50', icon: Check, label: 'Pass' },
    warning: { color: 'text-amber-600', bg: 'bg-amber-50', icon: AlertTriangle, label: 'Warning' },
    fail: { color: 'text-rose-600', bg: 'bg-rose-50', icon: X, label: 'Fail' },
  };
  const cfg = config[check.status];
  const StatusIcon = cfg.icon;

  return (
    <div className="flex items-start gap-3 px-5 py-3.5">
      <div className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg ${cfg.bg} ${cfg.color}`}>
        <Icon size={15} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-semibold text-slate-700">{check.label}</p>
          <span
            className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${cfg.bg} ${cfg.color}`}
          >
            <StatusIcon size={11} />
            {cfg.label}
          </span>
        </div>
        <p className="mt-0.5 text-xs text-slate-500 leading-relaxed">{check.detail}</p>
      </div>
    </div>
  );
}
