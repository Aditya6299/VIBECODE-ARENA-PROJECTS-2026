import { ShieldCheck, ScanLine, Flag, LayoutDashboard } from 'lucide-react';
import { useStore } from '@/store/useStore';
import type { View } from '@/types';

const navItems: { view: View; label: string; icon: typeof ShieldCheck; desc: string }[] = [
  { view: 'consumer', label: 'Consumer Portal', icon: ScanLine, desc: 'Verify products' },
  { view: 'reporting', label: 'Report a Fake', icon: Flag, desc: 'Submit a report' },
  { view: 'admin', label: 'Admin Dashboard', icon: LayoutDashboard, desc: 'Manage database' },
];

export function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const activeView = useStore((s) => s.activeView);
  const setView = useStore((s) => s.setView);
  const reports = useStore((s) => s.reports);
  const pendingCount = reports.filter((r) => r.status === 'Pending').length;

  const handleSelect = (view: View) => {
    setView(view);
    onClose();
  };

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-30 bg-slate-900/40 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}
      <aside
        className={`fixed lg:sticky top-0 left-0 z-40 h-screen w-72 flex-shrink-0 transform border-r border-slate-200 bg-white transition-transform duration-300 lg:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex items-center gap-3 px-6 py-5 border-b border-slate-200">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-600 text-white shadow-md">
              <ShieldCheck size={22} />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-800 leading-tight">TrustMark</h1>
              <p className="text-xs text-slate-400">Counterfeit Detection</p>
            </div>
          </div>

          {/* Nav */}
          <nav className="flex-1 px-3 py-4 space-y-1.5">
            <p className="px-3 py-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
              Navigation
            </p>
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeView === item.view;
              return (
                <button
                  key={item.view}
                  onClick={() => handleSelect(item.view)}
                  className={`group flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition-all duration-200 ${
                    active
                      ? 'bg-brand-50 text-brand-700'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <div className={`flex h-9 w-9 items-center justify-center rounded-lg transition-colors ${
                    active ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-500 group-hover:bg-slate-200'
                  }`}>
                    <Icon size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold leading-tight">{item.label}</p>
                    <p className="text-xs text-slate-400 truncate">{item.desc}</p>
                  </div>
                  {item.view === 'admin' && pendingCount > 0 && (
                    <span
                      className="group/badge relative flex h-5 min-w-[20px] items-center justify-center rounded-full bg-rose-500 px-1.5 text-xs font-bold text-white"
                      title={`${pendingCount} pending consumer report${pendingCount !== 1 ? 's' : ''}`}
                    >
                      {pendingCount}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Footer */}
          <div className="border-t border-slate-200 px-6 py-4">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-200 text-xs font-bold text-slate-500">
                AD
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-700 truncate">Admin User</p>
                <p className="text-xs text-slate-400">Database Manager</p>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
