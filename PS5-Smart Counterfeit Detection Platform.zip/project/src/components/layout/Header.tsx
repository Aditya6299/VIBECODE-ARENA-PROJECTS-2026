import { Menu, Bell, Globe } from 'lucide-react';
import { useStore } from '@/store/useStore';

const titles: Record<string, { title: string; subtitle: string }> = {
  consumer: { title: 'Consumer Portal', subtitle: 'Verify the authenticity of any product' },
  reporting: { title: 'Report a Fake', subtitle: 'Help protect consumers by reporting suspected counterfeits' },
  admin: { title: 'Admin Dashboard', subtitle: 'Manage product database and review reports' },
};

export function Header({ onMenuClick }: { onMenuClick: () => void }) {
  const activeView = useStore((s) => s.activeView);
  const info = titles[activeView];

  return (
    <header className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-200 bg-white/80 px-4 py-3.5 backdrop-blur-md lg:px-8">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenuClick}
          className="rounded-lg p-2 text-slate-500 transition-colors hover:bg-slate-100 lg:hidden"
        >
          <Menu size={20} />
        </button>
        <div>
          <h2 className="text-lg font-bold text-slate-800 leading-tight">{info.title}</h2>
          <p className="hidden text-sm text-slate-400 sm:block">{info.subtitle}</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="hidden items-center gap-2 rounded-lg bg-slate-100 px-3 py-2 text-sm text-slate-500 md:flex">
          <Globe size={16} />
          <span className="font-medium">Global Network</span>
        </div>
        <button className="relative rounded-lg p-2 text-slate-500 transition-colors hover:bg-slate-100">
          <Bell size={20} />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-rose-500" />
        </button>
      </div>
    </header>
  );
}
