import { useState } from 'react';
import { Plus, Edit2, Trash2, Package, Search } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { Modal } from '@/components/ui/Modal';
import type { Product, ProductCategory } from '@/types';

const categories: ProductCategory[] = ['Cosmetics', 'Medicines', 'Electronics', 'Clothing', 'Consumer Goods'];

const emptyForm: Omit<Product, 'id'> = {
  brand: '',
  name: '',
  category: 'Cosmetics',
  batchNumber: '',
  manufactureDate: '',
  expiryDate: '',
  referenceImageUrl: '',
  authorizedDistributor: '',
};

export function ProductManagement() {
  const products = useStore((s) => s.products);
  const addProduct = useStore((s) => s.addProduct);
  const updateProduct = useStore((s) => s.updateProduct);
  const deleteProduct = useStore((s) => s.deleteProduct);

  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Omit<Product, 'id'>>(emptyForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);

  const filtered = products.filter(
    (p) =>
      !search ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.brand.toLowerCase().includes(search.toLowerCase()) ||
      p.batchNumber.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => {
    setForm(emptyForm);
    setEditingId(null);
    setErrors({});
    setModalOpen(true);
  };

  const openEdit = (product: Product) => {
    const { id, ...rest } = product;
    void id;
    setForm(rest);
    setEditingId(product.id);
    setErrors({});
    setModalOpen(true);
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.brand.trim()) e.brand = 'Required';
    if (!form.name.trim()) e.name = 'Required';
    if (!form.batchNumber.trim()) e.batchNumber = 'Required';
    if (!form.referenceImageUrl.trim()) e.referenceImageUrl = 'Required';
    if (!form.authorizedDistributor.trim()) e.authorizedDistributor = 'Required';
    if (!form.manufactureDate) e.manufactureDate = 'Required';
    if (!form.expiryDate) e.expiryDate = 'Required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    if (editingId) {
      updateProduct(editingId, form);
    } else {
      addProduct(form);
    }
    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search products..."
            className="input-field pl-10"
          />
        </div>
        <button onClick={openAdd} className="btn-primary">
          <Plus size={18} />
          Add Product
        </button>
      </div>

      {/* Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((product) => (
          <div key={product.id} className="card overflow-hidden hover:shadow-md transition-shadow">
            <img src={product.referenceImageUrl} alt={product.name} className="h-36 w-full object-cover" />
            <div className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <span className="inline-block rounded-md bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-600">
                    {product.category}
                  </span>
                  <h3 className="mt-2 text-sm font-semibold text-slate-800 truncate">{product.name}</h3>
                  <p className="text-xs text-slate-500">{product.brand}</p>
                </div>
              </div>
              <div className="mt-3 space-y-1 text-xs text-slate-400">
                <p>Batch: <span className="text-slate-600 font-medium">{product.batchNumber}</span></p>
                <p>Distributor: <span className="text-slate-600">{product.authorizedDistributor}</span></p>
              </div>
              <div className="mt-4 flex gap-2 border-t border-slate-100 pt-3">
                <button onClick={() => openEdit(product)} className="btn-ghost btn-sm flex-1">
                  <Edit2 size={14} />
                  Edit
                </button>
                <button
                  onClick={() => setDeleteTarget(product)}
                  className="btn-ghost btn-sm flex-1 text-rose-600 hover:bg-rose-50"
                >
                  <Trash2 size={14} />
                  Remove
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="card flex flex-col items-center justify-center py-12 text-center">
          <Package size={32} className="text-slate-300" />
          <p className="mt-3 text-sm text-slate-500">No products found.</p>
        </div>
      )}

      {/* Add/Edit modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingId ? 'Edit Product' : 'Add New Product'}
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Brand" error={errors.brand} required>
              <input
                type="text"
                value={form.brand}
                onChange={(e) => setForm({ ...form, brand: e.target.value })}
                className={`input-field ${errors.brand ? 'border-rose-400' : ''}`}
                placeholder="e.g., LuxeAura"
              />
            </FormField>
            <FormField label="Category" required>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value as ProductCategory })}
                className="input-field"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </FormField>
          </div>

          <FormField label="Product Name" error={errors.name} required>
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className={`input-field ${errors.name ? 'border-rose-400' : ''}`}
              placeholder="e.g., Radiance Revival Serum"
            />
          </FormField>

          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Batch Number" error={errors.batchNumber} required>
              <input
                type="text"
                value={form.batchNumber}
                onChange={(e) => setForm({ ...form, batchNumber: e.target.value })}
                className={`input-field ${errors.batchNumber ? 'border-rose-400' : ''}`}
                placeholder="e.g., LA-2024-0847"
              />
            </FormField>
            <FormField label="Authorized Distributor" error={errors.authorizedDistributor} required>
              <input
                type="text"
                value={form.authorizedDistributor}
                onChange={(e) => setForm({ ...form, authorizedDistributor: e.target.value })}
                className={`input-field ${errors.authorizedDistributor ? 'border-rose-400' : ''}`}
                placeholder="e.g., AuraBeauty Distribution Ltd."
              />
            </FormField>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Manufacture Date" error={errors.manufactureDate} required>
              <input
                type="date"
                value={form.manufactureDate}
                onChange={(e) => setForm({ ...form, manufactureDate: e.target.value })}
                className={`input-field ${errors.manufactureDate ? 'border-rose-400' : ''}`}
              />
            </FormField>
            <FormField label="Expiry Date" error={errors.expiryDate} required>
              <input
                type="date"
                value={form.expiryDate}
                onChange={(e) => setForm({ ...form, expiryDate: e.target.value })}
                className={`input-field ${errors.expiryDate ? 'border-rose-400' : ''}`}
              />
            </FormField>
          </div>

          <FormField label="Reference Image URL" error={errors.referenceImageUrl} required>
            <input
              type="url"
              value={form.referenceImageUrl}
              onChange={(e) => setForm({ ...form, referenceImageUrl: e.target.value })}
              className={`input-field ${errors.referenceImageUrl ? 'border-rose-400' : ''}`}
              placeholder="https://images.unsplash.com/..."
            />
          </FormField>

          {form.referenceImageUrl && (
            <img src={form.referenceImageUrl} alt="Preview" className="h-32 w-full rounded-lg object-cover" />
          )}

          <div className="flex justify-end gap-3 border-t border-slate-100 pt-4">
            <button type="button" onClick={() => setModalOpen(false)} className="btn-ghost">
              Cancel
            </button>
            <button type="submit" className="btn-primary">
              {editingId ? 'Save Changes' : 'Add Product'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete confirm */}
      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Confirm Deletion" maxWidth="max-w-md">
        {deleteTarget && (
          <div className="space-y-4">
            <div className="flex items-start gap-3 rounded-lg bg-rose-50 p-4">
              <Trash2 size={20} className="flex-shrink-0 text-rose-600" />
              <div>
                <p className="text-sm font-medium text-rose-800">
                  Remove "{deleteTarget.name}" from the database?
                </p>
                <p className="mt-1 text-xs text-rose-600">
                  This action cannot be undone. All verification logs for this product will remain.
                </p>
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={() => setDeleteTarget(null)} className="btn-ghost">
                Cancel
              </button>
              <button
                onClick={() => {
                  deleteProduct(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                className="btn-danger"
              >
                <Trash2 size={16} />
                Delete
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function FormField({
  label,
  error,
  required,
  children,
}: {
  label: string;
  error?: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-slate-700">
        {label} {required && <span className="text-rose-500">*</span>}
      </label>
      {children}
      {error && <p className="mt-1 text-xs text-rose-500">{error}</p>}
    </div>
  );
}
