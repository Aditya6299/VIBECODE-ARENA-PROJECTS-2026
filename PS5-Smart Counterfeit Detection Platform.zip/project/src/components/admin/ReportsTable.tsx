import { useState } from 'react';
import { Flag, Eye, Search, Clock, MapPin, Search as SearchIcon } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { Badge } from '@/components/ui/Badge';
import { Modal } from '@/components/ui/Modal';
import type { Report, ReportStatus } from '@/types';

const ALL_FILTERS: { id: ReportStatus | 'all'; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'Pending', label: 'Pending' },
  { id: 'Investigating', label: 'Investigating' },
  { id: 'Resolved', label: 'Resolved' },
  { id: 'Dismissed', label: 'Dismissed' },
];

export function ReportsTable() {
  const reports = useStore((s) => s.reports);
  const updateReportStatus = useStore((s) => s.updateReportStatus);
  const [filter, setFilter] = useState<ReportStatus | 'all'>('all');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Report | null>(null);

  let filtered = filter === 'all' ? reports : reports.filter((r) => r.status === filter);
  if (search.trim()) {
    const q = search.toLowerCase();
    filtered = filtered.filter(
      (r) =>
        r.brand.toLowerCase().includes(q) ||
        r.purchaseLocation.toLowerCase().includes(q) ||
        r.consumerNotes.toLowerCase().includes(q)
    );
  }

  return (
    <div className="space-y-4">
      {/* Filter + search */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          {ALL_FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                filter === f.id
                  ? 'bg-brand-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {f.label}
              <span className="ml-1.5 opacity-70">
                {f.id === 'all' ? reports.length : reports.filter((r) => r.status === f.id).length}
              </span>
            </button>
          ))}
        </div>
        <div className="relative sm:max-w-xs">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search reports..."
            className="input-field pl-9 py-2 text-sm"
          />
        </div>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase tracking-wide text-slate-400">
              <tr>
                <th className="px-4 py-3 font-semibold">Report</th>
                <th className="hidden px-4 py-3 font-semibold sm:table-cell">Location</th>
                <th className="hidden px-4 py-3 font-semibold md:table-cell">Date</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((r) => (
                <tr key={r.id} className="transition-colors hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <img src={r.imageUrl} alt={r.brand} className="h-10 w-10 flex-shrink-0 rounded-lg object-cover" />
                      <div className="min-w-0">
                        <p className="font-semibold text-slate-700 truncate">{r.brand}</p>
                        <p className="text-xs text-slate-400 truncate max-w-[180px]">{r.consumerNotes}</p>
                      </div>
                    </div>
                  </td>
                  <td className="hidden px-4 py-3 sm:table-cell">
                    <div className="flex items-center gap-1.5 text-xs text-slate-500">
                      <MapPin size={14} className="text-slate-400" />
                      <span className="truncate max-w-[150px]">{r.purchaseLocation}</span>
                    </div>
                  </td>
                  <td className="hidden px-4 py-3 md:table-cell">
                    <div className="flex items-center gap-1.5 text-xs text-slate-500">
                      <Clock size={14} className="text-slate-400" />
                      {new Date(r.createdAt).toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <Badge status={r.status} />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setSelected(r)}
                        className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-brand-50 hover:text-brand-600"
                        title="View details"
                      >
                        <Eye size={16} />
                      </button>
                      {r.status === 'Pending' && (
                        <button
                          onClick={() => updateReportStatus(r.id, 'Investigating')}
                          className="rounded-lg px-2.5 py-1.5 text-xs font-medium text-sky-600 transition-colors hover:bg-sky-50"
                          title="Start investigating"
                        >
                          <SearchIcon size={14} className="inline mr-1" />
                          Investigate
                        </button>
                      )}
                      {(r.status === 'Pending' || r.status === 'Investigating') && (
                        <button
                          onClick={() => updateReportStatus(r.id, 'Resolved')}
                          className="rounded-lg px-2.5 py-1.5 text-xs font-medium text-emerald-600 transition-colors hover:bg-emerald-50"
                          title="Mark as resolved"
                        >
                          Resolve
                        </button>
                      )}
                      {r.status !== 'Dismissed' && r.status !== 'Resolved' && (
                        <button
                          onClick={() => updateReportStatus(r.id, 'Dismissed')}
                          className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
                          title="Dismiss report"
                        >
                          ×
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Flag size={36} className="text-slate-300" />
            <p className="mt-3 text-sm font-medium text-slate-500">No reports in this category</p>
            <p className="mt-1 text-xs text-slate-400">
              {search ? 'Try a different search term' : 'Consumer-submitted reports will appear here'}
            </p>
          </div>
        )}
      </div>

      {/* Detail modal */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title="Report Details" maxWidth="max-w-xl">
        {selected && (
          <div className="space-y-4">
            <img src={selected.imageUrl} alt={selected.brand} className="h-48 w-full rounded-lg object-cover" />
            <div className="grid gap-3 sm:grid-cols-2">
              <DetailItem label="Brand" value={selected.brand} />
              <DetailItem label="Status" value={<Badge status={selected.status} />} />
              <DetailItem label="Purchase Location" value={selected.purchaseLocation} />
              <DetailItem label="Date Submitted" value={new Date(selected.createdAt).toLocaleString()} />
            </div>
            <div>
              <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-400">Consumer Notes</p>
              <p className="rounded-lg bg-slate-50 p-3 text-sm text-slate-600">{selected.consumerNotes}</p>
            </div>

            {/* Action buttons */}
            <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-4">
              {selected.status === 'Pending' && (
                <button
                  onClick={() => {
                    updateReportStatus(selected.id, 'Investigating');
                    setSelected(null);
                  }}
                  className="btn-secondary flex-1"
                >
                  <SearchIcon size={16} />
                  Mark Investigating
                </button>
              )}
              {(selected.status === 'Pending' || selected.status === 'Investigating') && (
                <button
                  onClick={() => {
                    updateReportStatus(selected.id, 'Resolved');
                    setSelected(null);
                  }}
                  className="btn-success flex-1"
                >
                  Mark Resolved
                </button>
              )}
              {selected.status !== 'Dismissed' && selected.status !== 'Resolved' && (
                <button
                  onClick={() => {
                    updateReportStatus(selected.id, 'Dismissed');
                    setSelected(null);
                  }}
                  className="btn-ghost flex-1 text-slate-500"
                >
                  Dismiss
                </button>
              )}
              {(selected.status === 'Resolved' || selected.status === 'Dismissed') && (
                <button
                  onClick={() => {
                    updateReportStatus(selected.id, 'Pending');
                    setSelected(null);
                  }}
                  className="btn-ghost flex-1"
                >
                  Reopen Report
                </button>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function DetailItem({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</p>
      <div className="mt-0.5 text-sm text-slate-700">{value}</div>
    </div>
  );
}
