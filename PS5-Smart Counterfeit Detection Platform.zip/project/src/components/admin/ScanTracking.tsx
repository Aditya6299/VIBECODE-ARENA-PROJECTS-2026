import { useState } from 'react';
import { Activity, MapPin, Clock, Filter, TrendingUp } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { Badge } from '@/components/ui/Badge';
import type { VerificationStatus } from '@/types';

export function ScanTracking() {
  const logs = useStore((s) => s.verificationLogs);
  const products = useStore((s) => s.products);
  const [statusFilter, setStatusFilter] = useState<VerificationStatus | 'all'>('all');

  const filtered = statusFilter === 'all' ? logs : logs.filter((l) => l.status === statusFilter);

  const filters: { id: VerificationStatus | 'all'; label: string }[] = [
    { id: 'all', label: 'All Scans' },
    { id: 'Genuine', label: 'Genuine' },
    { id: 'Suspicious', label: 'Suspicious' },
    { id: 'Counterfeit', label: 'Counterfeit' },
  ];

  const productMap = new Map(products.map((p) => [p.id, p]));

  // Sort by timestamp desc
  const sorted = [...filtered].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  return (
    <div className="space-y-4">
      {/* Summary bar */}
      <div className="grid gap-4 sm:grid-cols-3">
        <SummaryStat
          icon={TrendingUp}
          label="Total Scans"
          value={logs.length}
          color="bg-brand-50 text-brand-600"
        />
        <SummaryStat
          icon={MapPin}
          label="Unique Locations"
          value={new Set(logs.map((l) => l.location)).size}
          color="bg-amber-50 text-amber-600"
        />
        <SummaryStat
          icon={Activity}
          label="Flagged Scans"
          value={logs.filter((l) => l.status !== 'Genuine').length}
          color="bg-rose-50 text-rose-600"
        />
      </div>

      {/* Filter */}
      <div className="flex items-center gap-2">
        <Filter size={16} className="text-slate-400" />
        {filters.map((f) => (
          <button
            key={f.id}
            onClick={() => setStatusFilter(f.id)}
            className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
              statusFilter === f.id
                ? 'bg-brand-600 text-white'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase tracking-wide text-slate-400">
              <tr>
                <th className="px-4 py-3 font-semibold">Product</th>
                <th className="px-4 py-3 font-semibold">Location</th>
                <th className="px-4 py-3 font-semibold">Timestamp</th>
                <th className="px-4 py-3 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sorted.map((log) => {
                const product = productMap.get(log.productId);
                return (
                  <tr key={log.id} className="transition-colors hover:bg-slate-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        {product && (
                          <img
                            src={product.referenceImageUrl}
                            alt={product.name}
                            className="h-9 w-9 rounded-lg object-cover flex-shrink-0"
                          />
                        )}
                        <div className="min-w-0">
                          <p className="font-medium text-slate-700 truncate">
                            {product ? product.name : 'Unknown Product'}
                          </p>
                          <p className="text-xs text-slate-400">
                            {product ? product.brand : log.productId}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <MapPin size={14} className="text-slate-400" />
                        {log.location}
                      </div>
                      <p className="mt-0.5 text-[11px] text-slate-400" title={`Query: ${log.query}`}>
                        via {log.method}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <Clock size={14} className="text-slate-400" />
                        {new Date(log.timestamp).toLocaleString()}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge status={log.status} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {sorted.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Activity size={32} className="text-slate-300" />
            <p className="mt-3 text-sm text-slate-500">No scan records found.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function SummaryStat({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: typeof Activity;
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div className="card flex items-center gap-4 p-5">
      <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${color}`}>
        <Icon size={20} />
      </div>
      <div>
        <p className="text-2xl font-bold text-slate-800">{value}</p>
        <p className="text-xs text-slate-400">{label}</p>
      </div>
    </div>
  );
}
