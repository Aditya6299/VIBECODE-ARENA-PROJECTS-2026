import { useState } from 'react';
import {
  ShieldCheck,
  Flag,
  Package,
  Activity,
  TrendingUp,
  AlertTriangle,
  ScanLine,
  Info,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { useStore } from '@/store/useStore';
import { ReportsTable } from './ReportsTable';
import { ProductManagement } from './ProductManagement';
import { ScanTracking } from './ScanTracking';
import { Badge } from '@/components/ui/Badge';

type AdminTab = 'overview' | 'reports' | 'products' | 'scans';

export function AdminDashboard() {
  const [tab, setTab] = useState<AdminTab>('overview');
  const products = useStore((s) => s.products);
  const reports = useStore((s) => s.reports);
  const verificationLogs = useStore((s) => s.verificationLogs);

  const pendingReports = reports.filter((r) => r.status === 'Pending').length;
  const investigatingReports = reports.filter((r) => r.status === 'Investigating').length;
  const counterfeitCount = verificationLogs.filter((l) => l.status === 'Counterfeit').length;
  const suspiciousCount = verificationLogs.filter((l) => l.status === 'Suspicious').length;
  const genuineCount = verificationLogs.filter((l) => l.status === 'Genuine').length;

  // Scans today
  const today = new Date().toDateString();
  const scansToday = verificationLogs.filter(
    (l) => new Date(l.timestamp).toDateString() === today
  ).length;

  // Active suspicious codes flagged (unique product IDs with suspicious/counterfeit status)
  const flaggedProductIds = new Set(
    verificationLogs
      .filter((l) => l.status === 'Suspicious' || l.status === 'Counterfeit')
      .map((l) => l.productId)
  );

  const tabs: { id: AdminTab; label: string; icon: typeof ShieldCheck; badge?: number }[] = [
    { id: 'overview', label: 'Overview', icon: TrendingUp },
    { id: 'reports', label: 'Reported Fakes', icon: Flag, badge: pendingReports + investigatingReports },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'scans', label: 'Scan Tracking', icon: Activity },
  ];

  return (
    <div className="space-y-6">
      {/* Metrics header — the three required KPIs */}
      <div className="grid gap-4 sm:grid-cols-3">
        <MetricCard
          icon={ScanLine}
          label="Total Scans Today"
          value={scansToday}
          color="brand"
          tooltip="All verification checks performed by consumers in the last 24 hours"
        />
        <MetricCard
          icon={AlertTriangle}
          label="Suspicious Codes Flagged"
          value={flaggedProductIds.size}
          color="amber"
          tooltip="Unique product identifiers flagged as suspicious or counterfeit across all scans"
        />
        <MetricCard
          icon={Flag}
          label="Pending Consumer Reports"
          value={pendingReports}
          color="rose"
          tooltip="Consumer-submitted counterfeit reports awaiting admin review"
        />
      </div>

      {/* Secondary stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={Package} label="Total Products" value={products.length} color="brand" />
        <StatCard icon={CheckCircle2} label="Genuine Scans" value={genuineCount} color="emerald" />
        <StatCard icon={AlertTriangle} label="Suspicious Scans" value={suspiciousCount} color="amber" />
        <StatCard icon={ShieldCheck} label="Counterfeit Detected" value={counterfeitCount} color="rose" />
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto rounded-xl border border-slate-200 bg-white p-1.5 shadow-sm">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex flex-shrink-0 items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-all ${
                active ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Icon size={16} />
              {t.label}
              {t.badge ? (
                <span
                  className={`flex h-5 min-w-[20px] items-center justify-center rounded-full px-1.5 text-xs font-bold ${
                    active ? 'bg-white/25 text-white' : 'bg-rose-500 text-white'
                  }`}
                >
                  {t.badge}
                </span>
              ) : null}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div key={tab} className="animate-fade-in">
        {tab === 'overview' && (
          <OverviewTab
            products={products.length}
            reports={reports}
            logs={verificationLogs}
            genuineCount={genuineCount}
            suspiciousCount={suspiciousCount}
            counterfeitCount={counterfeitCount}
            scansToday={scansToday}
            flaggedCount={flaggedProductIds.size}
            pendingReports={pendingReports}
          />
        )}
        {tab === 'reports' && <ReportsTable />}
        {tab === 'products' && <ProductManagement />}
        {tab === 'scans' && <ScanTracking />}
      </div>
    </div>
  );
}

function MetricCard({
  icon: Icon,
  label,
  value,
  color,
  tooltip,
}: {
  icon: typeof Package;
  label: string;
  value: number;
  color: 'brand' | 'amber' | 'rose';
  tooltip: string;
}) {
  const colorMap = {
    brand: 'bg-brand-500 text-white',
    amber: 'bg-amber-500 text-white',
    rose: 'bg-rose-500 text-white',
  };
  return (
    <div className="card relative p-5">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-1.5">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</p>
            <div className="group relative">
              <Info size={13} className="text-slate-300 hover:text-slate-500 cursor-help" />
              <div className="pointer-events-none absolute bottom-full left-1/2 z-20 mb-2 -translate-x-1/2 whitespace-nowrap rounded-lg bg-slate-800 px-3 py-1.5 text-xs text-white opacity-0 shadow-lg transition-opacity duration-200 group-hover:opacity-100">
                {tooltip}
              </div>
            </div>
          </div>
          <p className="mt-2 text-3xl font-bold text-slate-800">{value}</p>
        </div>
        <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${colorMap[color]}`}>
          <Icon size={22} />
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: typeof Package;
  label: string;
  value: number;
  color: 'brand' | 'amber' | 'rose' | 'emerald';
}) {
  const colorMap = {
    brand: 'bg-brand-50 text-brand-600',
    amber: 'bg-amber-50 text-amber-600',
    rose: 'bg-rose-50 text-rose-600',
    emerald: 'bg-emerald-50 text-emerald-600',
  };
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{label}</p>
          <p className="mt-1 text-2xl font-bold text-slate-800">{value}</p>
        </div>
        <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${colorMap[color]}`}>
          <Icon size={20} />
        </div>
      </div>
    </div>
  );
}

function OverviewTab({
  products,
  reports,
  logs,
  genuineCount,
  suspiciousCount,
  counterfeitCount,
  scansToday,
  flaggedCount,
  pendingReports,
}: {
  products: number;
  reports: ReturnType<typeof useStore.getState>['reports'];
  logs: ReturnType<typeof useStore.getState>['verificationLogs'];
  genuineCount: number;
  suspiciousCount: number;
  counterfeitCount: number;
  scansToday: number;
  flaggedCount: number;
  pendingReports: number;
}) {
  const totalScans = logs.length;
  const genuinePct = totalScans ? Math.round((genuineCount / totalScans) * 100) : 0;
  const suspiciousPct = totalScans ? Math.round((suspiciousCount / totalScans) * 100) : 0;
  const counterfeitPct = totalScans ? Math.round((counterfeitCount / totalScans) * 100) : 0;

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Scan breakdown */}
      <div className="card p-6">
        <h3 className="mb-4 text-sm font-semibold text-slate-700">Verification Breakdown</h3>
        {totalScans > 0 ? (
          <div className="space-y-4">
            <BreakdownBar label="Genuine" count={genuineCount} pct={genuinePct} color="bg-emerald-500" />
            <BreakdownBar label="Suspicious" count={suspiciousCount} pct={suspiciousPct} color="bg-amber-500" />
            <BreakdownBar label="Counterfeit" count={counterfeitCount} pct={counterfeitPct} color="bg-rose-500" />
          </div>
        ) : (
          <EmptyState icon={Activity} message="No verification scans yet" />
        )}
        <div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-4 text-sm">
          <span className="text-slate-500">Total Verifications</span>
          <span className="font-bold text-slate-800">{totalScans}</span>
        </div>
      </div>

      {/* Recent reports */}
      <div className="card p-6">
        <h3 className="mb-4 text-sm font-semibold text-slate-700">Recent Consumer Reports</h3>
        {reports.length > 0 ? (
          <div className="space-y-3">
            {reports.slice(0, 5).map((r) => (
              <div key={r.id} className="flex items-start gap-3 rounded-lg bg-slate-50 p-3">
                <img
                  src={r.imageUrl}
                  alt={r.brand}
                  className="h-12 w-12 flex-shrink-0 rounded-lg object-cover"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-sm font-semibold text-slate-700">{r.brand}</p>
                    <Badge status={r.status} />
                  </div>
                  <p className="mt-0.5 truncate text-xs text-slate-400">{r.purchaseLocation}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState icon={Flag} message="No consumer reports submitted yet" />
        )}
      </div>

      {/* Summary */}
      <div className="card p-6 lg:col-span-2">
        <h3 className="mb-4 text-sm font-semibold text-slate-700">Database Summary</h3>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          <SummaryItem label="Products" value={products} />
          <SummaryItem label="Total Scans" value={totalScans} />
          <SummaryItem label="Scans Today" value={scansToday} />
          <SummaryItem label="Flagged Codes" value={flaggedCount} />
          <SummaryItem label="Pending Reports" value={pendingReports} />
          <SummaryItem label="Total Reports" value={reports.length} />
        </div>
      </div>
    </div>
  );
}

function BreakdownBar({
  label,
  count,
  pct,
  color,
}: {
  label: string;
  count: number;
  pct: number;
  color: string;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between text-sm">
        <span className="font-medium text-slate-600">{label}</span>
        <span className="text-slate-400">
          {count} ({pct}%)
        </span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-slate-100">
        <div
          className={`h-full rounded-full ${color} transition-all duration-700`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

function SummaryItem({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg bg-slate-50 p-4 text-center">
      <p className="text-2xl font-bold text-slate-800">{value}</p>
      <p className="mt-0.5 text-xs text-slate-400">{label}</p>
    </div>
  );
}

function EmptyState({ icon: Icon, message }: { icon: typeof Activity; message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-10 text-center">
      <Icon size={32} className="text-slate-300" />
      <p className="mt-3 text-sm text-slate-500">{message}</p>
    </div>
  );
}
