import { useState, useRef } from 'react';
import { Flag, Upload, X, ImageIcon, Send, AlertTriangle } from 'lucide-react';
import { useStore } from '@/store/useStore';
import type { Product } from '@/types';

export function ReportingPortal() {
  const products = useStore((s) => s.products);
  const addReport = useStore((s) => s.addReport);
  const pushToast = useStore((s) => s.pushToast);
  const setView = useStore((s) => s.setView);

  const [brand, setBrand] = useState('');
  const [productId, setProductId] = useState('');
  const [purchaseLocation, setPurchaseLocation] = useState('');
  const [consumerNotes, setConsumerNotes] = useState('');
  const [imageUrl, setImageUrl] = useState<string>('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      pushToast('Please upload an image file', 'error');
      return;
    }
    const url = URL.createObjectURL(file);
    setImageUrl(url);
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!brand.trim()) e.brand = 'Brand is required';
    if (!purchaseLocation.trim()) e.purchaseLocation = 'Purchase location is required';
    if (!consumerNotes.trim()) e.consumerNotes = 'Please describe the issue';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      pushToast('Please fill in all required fields', 'error');
      return;
    }
    addReport({
      brand: brand.trim(),
      productId: productId || null,
      purchaseLocation: purchaseLocation.trim(),
      consumerNotes: consumerNotes.trim(),
      imageUrl: imageUrl || 'https://images.unsplash.com/photo-1607604276583-eef5d076aa7f?w=600',
    });
    setBrand('');
    setProductId('');
    setPurchaseLocation('');
    setConsumerNotes('');
    setImageUrl('');
    setErrors({});
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      {/* Banner */}
      <div className="flex items-start gap-4 rounded-xl border border-amber-200 bg-amber-50 p-5">
        <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-amber-100 text-amber-600">
          <AlertTriangle size={20} />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-amber-800">Report a Suspected Counterfeit</h3>
          <p className="mt-1 text-sm text-amber-700">
            Your report helps protect consumers worldwide. Provide as much detail as possible
            so our team can investigate effectively.
          </p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="card space-y-5 p-6">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-4">
          <Flag size={20} className="text-brand-600" />
          <h3 className="text-base font-semibold text-slate-800">Report Details</h3>
        </div>

        {/* Brand + Product */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">
              Brand <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              placeholder="e.g., SonicWave"
              className={`input-field ${errors.brand ? 'border-rose-400 ring-1 ring-rose-400' : ''}`}
            />
            {errors.brand && <p className="mt-1 text-xs text-rose-500">{errors.brand}</p>}
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">
              Matched Product (optional)
            </label>
            <select
              value={productId}
              onChange={(e) => setProductId(e.target.value)}
              className="input-field"
            >
              <option value="">Select if you know the product...</option>
              {products.map((p: Product) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Purchase location */}
        <div>
          <label className="mb-1.5 block text-sm font-medium text-slate-700">
            Purchase Location <span className="text-rose-500">*</span>
          </label>
          <input
            type="text"
            value={purchaseLocation}
            onChange={(e) => setPurchaseLocation(e.target.value)}
            placeholder="e.g., Online store, street market, shop name and address"
            className={`input-field ${errors.purchaseLocation ? 'border-rose-400 ring-1 ring-rose-400' : ''}`}
          />
          {errors.purchaseLocation && (
            <p className="mt-1 text-xs text-rose-500">{errors.purchaseLocation}</p>
          )}
        </div>

        {/* Notes */}
        <div>
          <label className="mb-1.5 block text-sm font-medium text-slate-700">
            Describe the Issue <span className="text-rose-500">*</span>
          </label>
          <textarea
            value={consumerNotes}
            onChange={(e) => setConsumerNotes(e.target.value)}
            rows={4}
            placeholder="What made you suspect this product is fake? Differences in packaging, quality, labeling, etc."
            className={`input-field resize-none ${errors.consumerNotes ? 'border-rose-400 ring-1 ring-rose-400' : ''}`}
          />
          {errors.consumerNotes && (
            <p className="mt-1 text-xs text-rose-500">{errors.consumerNotes}</p>
          )}
        </div>

        {/* Image upload */}
        <div>
          <label className="mb-1.5 block text-sm font-medium text-slate-700">
            Product Image (optional)
          </label>
          {!imageUrl ? (
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const file = e.dataTransfer.files[0];
                if (file) handleFile(file);
              }}
              onClick={() => fileInputRef.current?.click()}
              className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-slate-300 bg-slate-50 py-10 transition-colors hover:border-brand-400 hover:bg-brand-50/50"
            >
              <Upload size={24} className="text-slate-400" />
              <p className="mt-2 text-sm text-slate-500">Click or drag to upload</p>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFile(file);
                }}
              />
            </div>
          ) : (
            <div className="relative inline-block">
              <img src={imageUrl} alt="Report" className="h-40 rounded-lg object-cover" />
              <button
                type="button"
                onClick={() => setImageUrl('')}
                className="absolute top-2 right-2 rounded-lg bg-slate-900/60 p-1.5 text-white hover:bg-slate-900/80"
              >
                <X size={14} />
              </button>
            </div>
          )}
        </div>

        {/* Submit */}
        <div className="flex flex-col gap-3 border-t border-slate-100 pt-5 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={() => {
              setView('consumer');
            }}
            className="btn-ghost"
          >
            Cancel
          </button>
          <button type="submit" className="btn-primary">
            <Send size={16} />
            Submit Report
          </button>
        </div>
      </form>

      {/* Info */}
      <div className="flex items-start gap-3 rounded-xl bg-slate-100 p-4">
        <ImageIcon size={18} className="mt-0.5 flex-shrink-0 text-slate-400" />
        <p className="text-xs text-slate-500">
          Reports are reviewed by our verification team. If you've purchased a
          counterfeit product, we also recommend contacting the brand's official
          anti-counterfeit department and your local consumer protection agency.
        </p>
      </div>
    </div>
  );
}
