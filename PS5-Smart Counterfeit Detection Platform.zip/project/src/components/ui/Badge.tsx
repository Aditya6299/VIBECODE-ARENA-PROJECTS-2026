import { type ReactNode } from 'react';

interface BadgeProps {
  status: 'Genuine' | 'Suspicious' | 'Counterfeit' | 'Pending' | 'Investigating' | 'Resolved' | 'Dismissed';
  children?: ReactNode;
}

const styles: Record<BadgeProps['status'], string> = {
  Genuine: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Suspicious: 'bg-amber-50 text-amber-700 border-amber-200',
  Counterfeit: 'bg-rose-50 text-rose-700 border-rose-200',
  Pending: 'bg-amber-50 text-amber-700 border-amber-200',
  Investigating: 'bg-sky-50 text-sky-700 border-sky-200',
  Resolved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Dismissed: 'bg-slate-100 text-slate-500 border-slate-200',
};

export function Badge({ status, children }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold ${styles[status]}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${
        status === 'Genuine' || status === 'Resolved'
          ? 'bg-emerald-500'
          : status === 'Suspicious' || status === 'Pending'
          ? 'bg-amber-500'
          : status === 'Counterfeit'
          ? 'bg-rose-500'
          : status === 'Investigating'
          ? 'bg-sky-500'
          : 'bg-slate-400'
      }`} />
      {children || status}
    </span>
  );
}
