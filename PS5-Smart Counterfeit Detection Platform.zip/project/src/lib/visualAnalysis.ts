import type {
  VisualAnalysis,
  VisualCheckItem,
  VisualCheckStatus,
  Product,
} from '@/types';

/**
 * Deterministic pseudo-random generator seeded by a string.
 * Produces reproducible results for the same product + image combination.
 */
function seededRandom(seed: string): () => number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return () => {
    h ^= h << 13;
    h ^= h >>> 17;
    h ^= h << 5;
    return ((h >>> 0) % 10000) / 10000;
  };
}

const CHECK_TEMPLATES = [
  {
    label: 'Logo Typography Match',
    pass: 'Brand logo typography matches the reference. Font weight, letter spacing, and kerning are consistent.',
    warning: 'Minor font kerning anomaly detected on brand logo. Spacing between characters is slightly irregular.',
    fail: 'Logo typography does not match. Font weight and style differ significantly from the reference image.',
  },
  {
    label: 'Spelling Verification',
    pass: 'All text on packaging is correctly spelled. No typographical discrepancies detected.',
    warning: 'Possible minor spelling variation detected. One character may differ from the reference label.',
    fail: 'Spelling error detected on packaging label. Brand name or product text contains incorrect characters.',
  },
  {
    label: 'Label Alignment',
    pass: 'Label alignment matches the reference. Margins, spacing, and layout are consistent.',
    warning: 'Label alignment is slightly off. Margins differ by a small margin from the reference image.',
    fail: 'Label alignment is significantly different. Layout and positioning do not match the reference.',
  },
  {
    label: 'Color Saturation Score',
    pass: 'Color saturation matches the reference. Hue and brightness are within expected tolerance.',
    warning: 'Color saturation is slightly off. Hue shift detected that may indicate a reproduction.',
    fail: 'Color saturation differs significantly. Colors appear washed out or shifted from the reference.',
  },
];

/**
 * Simulate a visual packaging comparison analysis.
 *
 * Produces a deterministic-but-varied result based on a seed derived from
 * the product ID and user image identifier. High match scores are more
 * common when a product is found in the database; lower scores when the
 * product is unknown (simulating that counterfeit packaging is more likely
 * when the product itself is unrecognized).
 */
export function simulateVisualAnalysis(
  product: Product | null,
  userImageUrl: string | null,
  referenceImageUrl: string
): VisualAnalysis {
  const seed = `${product?.id ?? 'unknown'}-${userImageUrl ?? 'noimg'}`;
  const rng = seededRandom(seed);

  // Base match score: known products trend higher, unknown lower
  let baseScore = product ? 75 + rng() * 22 : 30 + rng() * 30;
  baseScore = Math.round(baseScore);

  const checks: VisualCheckItem[] = CHECK_TEMPLATES.map((tmpl) => {
    const roll = rng();
    let status: VisualCheckStatus;
    let detail: string;

    if (baseScore >= 85) {
      status = roll < 0.85 ? 'pass' : 'warning';
    } else if (baseScore >= 60) {
      status = roll < 0.5 ? 'pass' : roll < 0.85 ? 'warning' : 'fail';
    } else {
      status = roll < 0.25 ? 'pass' : roll < 0.6 ? 'warning' : 'fail';
    }

    detail = tmpl[status];

    return { label: tmpl.label, detail, status };
  });

  const passCount = checks.filter((c) => c.status === 'pass').length;
  const failCount = checks.filter((c) => c.status === 'fail').length;

  let summary: string;
  if (baseScore >= 85) {
    summary = `${baseScore}% Visual Match — Clean typography, no spelling discrepancies detected. Packaging details closely match the reference.`;
  } else if (baseScore >= 60) {
    const warningItem = checks.find((c) => c.status === 'warning');
    summary = `${baseScore}% Visual Match — ${passCount}/4 checks passed. ${warningItem ? `Warning: ${warningItem.label.toLowerCase()} shows minor discrepancies.` : 'Some minor variations detected.'}`;
  } else {
    const failItem = checks.find((c) => c.status === 'fail');
    summary = `${baseScore}% Visual Match — Only ${passCount}/4 checks passed. ${failItem ? `Critical: ${failItem.detail}` : 'Significant visual discrepancies detected across multiple checks.'}`;
  }

  return {
    matchScore: baseScore,
    checks,
    userImageUrl,
    referenceImageUrl,
    summary,
  };
}

/**
 * Convert a VisualAnalysis into RiskFactors that can be merged
 * into the overall risk assessment.
 */
export function visualAnalysisToFactors(
  visual: VisualAnalysis
): { factors: import('@/types').RiskFactor[]; scoreAdjustment: number } {
  const factors: import('@/types').RiskFactor[] = [];
  let adjustment = 0;

  factors.push({
    label: `Packaging Visual Match: ${visual.matchScore}%`,
    detail: visual.summary,
    impact: visual.matchScore >= 85 ? 'positive' : visual.matchScore >= 60 ? 'warning' : 'negative',
  });

  if (visual.matchScore >= 85) {
    adjustment += 10;
  } else if (visual.matchScore >= 60) {
    adjustment -= 8;
  } else {
    adjustment -= 25;
  }

  const failedChecks = visual.checks.filter((c) => c.status === 'fail');
  failedChecks.forEach((c) => {
    factors.push({
      label: `Visual Anomaly: ${c.label}`,
      detail: c.detail,
      impact: 'negative',
    });
    adjustment -= 5;
  });

  const warningChecks = visual.checks.filter((c) => c.status === 'warning');
  warningChecks.forEach((c) => {
    factors.push({
      label: `Visual Warning: ${c.label}`,
      detail: c.detail,
      impact: 'warning',
    });
    adjustment -= 2;
  });

  return { factors, scoreAdjustment: adjustment };
}
