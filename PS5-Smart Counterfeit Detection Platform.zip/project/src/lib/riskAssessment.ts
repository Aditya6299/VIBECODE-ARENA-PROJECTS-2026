import type {
  Product,
  VerificationLog,
  RiskAssessment,
  RiskLevel,
  RiskFactor,
  VisualAnalysis,
} from '@/types';
import { visualAnalysisToFactors } from '@/lib/visualAnalysis';

const SCAN_FREQUENCY_SUSPICIOUS_THRESHOLD = 5;
const SCAN_FREQUENCY_COUNTERFEIT_THRESHOLD = 12;
const RECENT_SCAN_WINDOW_HOURS = 24;

export function isBatchExpired(product: Product): boolean {
  if (!product.expiryDate) return false;
  const expiry = new Date(product.expiryDate).getTime();
  return expiry < Date.now();
}

/**
 * Count scans within the recent time window for a given productId.
 */
function countRecentScans(
  productId: string,
  logs: VerificationLog[],
  windowHours = RECENT_SCAN_WINDOW_HOURS
): { count: number; uniqueLocations: number } {
  const cutoff = Date.now() - windowHours * 60 * 60 * 1000;
  const recent = logs.filter(
    (l) =>
      l.productId === productId &&
      new Date(l.timestamp).getTime() >= cutoff
  );
  const count = recent.reduce((sum, l) => sum + (l.scanCount || 1), 0);
  const locationSet = new Set(recent.map((l) => l.location));
  return { count, uniqueLocations: locationSet.size };
}

/**
 * Look up a product by product ID or batch number (case-insensitive).
 */
export function findProduct(
  query: string,
  products: Product[]
): Product | null {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return null;
  return (
    products.find((p) => p.id.toLowerCase() === normalized) ??
    products.find((p) => p.batchNumber.toLowerCase() === normalized) ??
    null
  );
}

/**
 * Validate the identifier format.
 * Accepts patterns like:
 *  - Product IDs: "p-001", "P-001"
 *  - Batch numbers: "LA-2024-0847", "PC-2024-3321"
 */
export function isValidIdentifierFormat(query: string): boolean {
  const normalized = query.trim();
  if (!normalized) return false;
  return /^[a-zA-Z]{1,6}-\d{2,6}-?\d{0,6}$/.test(normalized);
}

/**
 * Core risk assessment algorithm.
 *
 * Produces an explainable RiskAssessment with a risk level, numeric
 * score (0–100, higher = safer), and a breakdown of contributing factors.
 *
 * Rules:
 *  - POTENTIALLY COUNTERFEIT (red): identifier not in database, or batch
 *    is expired / blacklisted.
 *  - NEEDS FURTHER VERIFICATION (amber): identifier exists and batch is
 *    valid, but scan frequency is unusually high in a short window
 *    (suspicious code reuse).
 *  - LIKELY GENUINE (green): identifier exists, batch is valid, scan
 *    frequency is normal.
 */
export function assessRisk(
  query: string,
  products: Product[],
  logs: VerificationLog[],
  blacklistedBatches: string[],
  method: 'scanner' | 'manual' | 'upload',
  location: string,
  visualAnalysis?: VisualAnalysis | null
): RiskAssessment {
  const factors: RiskFactor[] = [];
  let score = 50;
  const product = findProduct(query, products);
  const validFormat = isValidIdentifierFormat(query);

  if (product) {
    factors.push({
      label: 'Identifier matched in database',
      detail: `Product ID "${product.id}" and batch number "${product.batchNumber}" match authorized records for "${product.name}" by ${product.brand}.`,
      impact: 'positive',
    });
    score += 25;

    const expired = isBatchExpired(product);
    if (expired) {
      factors.push({
        label: 'Batch has expired',
        detail: `This batch's expiry date (${product.expiryDate}) has passed. Expired products may be repackaged or sold illegally.`,
        impact: 'negative',
      });
      score -= 35;
    } else {
      factors.push({
        label: 'Batch is within validity period',
        detail: `Manufactured on ${product.manufactureDate}, expires ${product.expiryDate}. Batch is currently valid.`,
        impact: 'positive',
      });
      score += 10;
    }

    const blacklisted = blacklistedBatches.some(
      (b) => b.toLowerCase() === product.batchNumber.toLowerCase()
    );
    if (blacklisted) {
      factors.push({
        label: 'Batch is blacklisted',
        detail: `Batch number "${product.batchNumber}" has been flagged by TrustMark as blacklisted due to confirmed counterfeit activity.`,
        impact: 'negative',
      });
      score -= 40;
    }

    const { count, uniqueLocations } = countRecentScans(product.id, logs);
    if (count >= SCAN_FREQUENCY_COUNTERFEIT_THRESHOLD) {
      factors.push({
        label: 'Critical scan frequency',
        detail: `Warning: This code has been scanned ${count} times in the last 24 hours from ${uniqueLocations} different location${uniqueLocations !== 1 ? 's' : ''}. This strongly suggests code reuse on counterfeit products.`,
        impact: 'negative',
      });
      score -= 30;
    } else if (count >= SCAN_FREQUENCY_SUSPICIOUS_THRESHOLD) {
      factors.push({
        label: 'Elevated scan frequency',
        detail: `Warning: This code has been scanned ${count} times in the last 24 hours from ${uniqueLocations} location${uniqueLocations !== 1 ? 's' : ''}. Legitimate codes are typically scanned 1–2 times. This may indicate code copying.`,
        impact: 'warning',
      });
      score -= 15;
    } else {
      factors.push({
        label: 'Scan frequency is normal',
        detail: `This code has been scanned ${count} time${count !== 1 ? 's' : ''} in the last 24 hours, which is within the expected range for a genuine product.`,
        impact: 'positive',
      });
      score += 5;
    }

    factors.push({
      label: 'Authorized distributor confirmed',
      detail: `"${product.authorizedDistributor}" is the verified distributor for this product. Verify your seller matches this distributor.`,
      impact: 'positive',
    });
    score += 5;
  } else {
    if (validFormat) {
      factors.push({
        label: 'Identifier format is valid but not found',
        detail: `The identifier "${query.trim()}" has a valid format but does not match any product in TrustMark's authorized database. This could mean the product is not registered or is counterfeit.`,
        impact: 'warning',
      });
      score -= 25;
    } else {
      factors.push({
        label: 'Identifier not recognized',
        detail: `"${query.trim()}" does not match any product ID or batch number in TrustMark's database. The format is also unrecognized — this is a strong indicator of a counterfeit product.`,
        impact: 'negative',
      });
      score -= 40;
    }
  }

  // Integrate visual analysis into the overall score and factors
  if (visualAnalysis) {
    const { factors: visualFactors, scoreAdjustment } = visualAnalysisToFactors(visualAnalysis);
    factors.push(...visualFactors);
    score += scoreAdjustment;
  }

  score = Math.max(0, Math.min(100, score));

  let level: RiskLevel;
  if (!product || isBatchExpired(product) || blacklistedBatches.includes(product?.batchNumber ?? '')) {
    level = 'Counterfeit';
  } else {
    const { count } = countRecentScans(product.id, logs);
    if (count >= SCAN_FREQUENCY_COUNTERFEIT_THRESHOLD) {
      level = 'Counterfeit';
    } else if (count >= SCAN_FREQUENCY_SUSPICIOUS_THRESHOLD || score < 55) {
      level = 'Suspicious';
    } else {
      level = 'Genuine';
    }
  }

  const { count, uniqueLocations } = product
    ? countRecentScans(product.id, logs)
    : { count: 0, uniqueLocations: 0 };

  return {
    level,
    score,
    factors,
    matchedProduct: product,
    query: query.trim(),
    method,
    timestamp: new Date().toISOString(),
    location,
    scanFrequency: count,
    uniqueLocations,
    isExpired: product ? isBatchExpired(product) : false,
    isBlacklisted: product
      ? blacklistedBatches.includes(product.batchNumber)
      : false,
    visualAnalysis: visualAnalysis ?? null,
  };
}

export const RISK_LEVEL_LABELS: Record<RiskLevel, string> = {
  Genuine: 'LIKELY GENUINE',
  Suspicious: 'NEEDS FURTHER VERIFICATION',
  Counterfeit: 'POTENTIALLY COUNTERFEIT',
};
