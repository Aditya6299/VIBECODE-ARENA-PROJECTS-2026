export type ProductCategory =
  | 'Cosmetics'
  | 'Medicines'
  | 'Electronics'
  | 'Clothing'
  | 'Consumer Goods';

export type RiskLevel = 'Genuine' | 'Suspicious' | 'Counterfeit';

export type VerificationStatus = RiskLevel;

export type ReportStatus = 'Pending' | 'Investigating' | 'Resolved' | 'Dismissed';

export interface Product {
  id: string;
  brand: string;
  name: string;
  category: ProductCategory;
  batchNumber: string;
  manufactureDate: string;
  expiryDate: string;
  referenceImageUrl: string;
  authorizedDistributor: string;
}

export interface VerificationLog {
  id: string;
  productId: string;
  timestamp: string;
  scanCount: number;
  location: string;
  status: VerificationStatus;
  /** The raw identifier the consumer entered (product ID or batch number). */
  query: string;
  /** Whether this entry was created via scanner or manual entry. */
  method: 'scanner' | 'manual' | 'upload';
  /** The full risk assessment at time of verification. */
  riskAssessment: RiskAssessment;
}

export interface RiskFactor {
  label: string;
  detail: string;
  /** Positive contribution → genuine; negative → suspicious/counterfeit. */
  impact: 'positive' | 'warning' | 'negative';
}

export type VisualCheckStatus = 'pass' | 'warning' | 'fail';

export interface VisualCheckItem {
  label: string;
  detail: string;
  status: VisualCheckStatus;
}

export interface VisualAnalysis {
  matchScore: number; // 0–100
  checks: VisualCheckItem[];
  userImageUrl: string | null;
  referenceImageUrl: string;
  summary: string;
}

export interface RiskAssessment {
  level: RiskLevel;
  score: number; // 0–100, higher = safer
  factors: RiskFactor[];
  matchedProduct: Product | null;
  query: string;
  method: 'scanner' | 'manual' | 'upload';
  timestamp: string;
  location: string;
  scanFrequency: number;
  uniqueLocations: number;
  isExpired: boolean;
  isBlacklisted: boolean;
  /** Present only when verification was done via image upload. */
  visualAnalysis: VisualAnalysis | null;
}

export interface Report {
  id: string;
  brand: string;
  productId: string | null;
  purchaseLocation: string;
  consumerNotes: string;
  imageUrl: string;
  status: ReportStatus;
  createdAt: string;
}

export type View = 'consumer' | 'reporting' | 'admin';

export type ConsumerTab = 'verify' | 'result' | 'history' | 'upload';
