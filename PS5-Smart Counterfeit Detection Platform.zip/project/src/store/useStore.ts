import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  Product,
  VerificationLog,
  Report,
  View,
  ConsumerTab,
  RiskAssessment,
  VisualAnalysis,
} from '@/types';
import {
  seedProducts,
  seedVerificationLogs,
  seedReports,
} from '@/data/seed';
import { assessRisk } from '@/lib/riskAssessment';

interface ToastMsg {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface TrustMarkState {
  products: Product[];
  verificationLogs: VerificationLog[];
  reports: Report[];
  blacklistedBatches: string[];

  activeView: View;
  consumerTab: ConsumerTab;
  toasts: ToastMsg[];
  lastRiskAssessment: RiskAssessment | null;

  setView: (view: View) => void;
  setConsumerTab: (tab: ConsumerTab) => void;

  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;

  addReport: (report: Omit<Report, 'id' | 'createdAt' | 'status'>) => void;
  updateReportStatus: (id: string, status: Report['status']) => void;

  verifyIdentifier: (
    query: string,
    method: 'scanner' | 'manual' | 'upload',
    location: string,
    visualAnalysis?: VisualAnalysis | null
  ) => RiskAssessment;

  pushToast: (message: string, type?: ToastMsg['type']) => void;
  removeToast: (id: string) => void;
}

function genId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}

export const useStore = create<TrustMarkState>()(
  persist(
    (set, get) => ({
      products: seedProducts,
      verificationLogs: seedVerificationLogs,
      reports: seedReports,
      blacklistedBatches: [],

      activeView: 'consumer',
      consumerTab: 'verify',
      toasts: [],
      lastRiskAssessment: null,

      setView: (view) => set({ activeView: view }),
      setConsumerTab: (tab) => set({ consumerTab: tab }),

      addProduct: (product) => {
        const newProduct: Product = { ...product, id: genId('p') };
        set((state) => ({ products: [...state.products, newProduct] }));
        get().pushToast('Product added to database', 'success');
      },

      updateProduct: (id, updates) => {
        set((state) => ({
          products: state.products.map((p) =>
            p.id === id ? { ...p, ...updates } : p
          ),
        }));
        get().pushToast('Product record updated', 'success');
      },

      deleteProduct: (id) => {
        set((state) => ({
          products: state.products.filter((p) => p.id !== id),
        }));
        get().pushToast('Product removed from database', 'info');
      },

      addReport: (report) => {
        const newReport: Report = {
          ...report,
          id: genId('r'),
          status: 'Pending',
          createdAt: new Date().toISOString(),
        };
        set((state) => ({ reports: [newReport, ...state.reports] }));
        get().pushToast('Report submitted successfully', 'success');
      },

      updateReportStatus: (id, status) => {
        set((state) => ({
          reports: state.reports.map((r) =>
            r.id === id ? { ...r, status } : r
          ),
        }));
        get().pushToast(`Report marked as ${status}`, 'success');
      },

      verifyIdentifier: (query, method, location, visualAnalysis) => {
        const state = get();
        const assessment = assessRisk(
          query,
          state.products,
          state.verificationLogs,
          state.blacklistedBatches,
          method,
          location,
          visualAnalysis
        );

        const newLog: VerificationLog = {
          id: genId('v'),
          productId: assessment.matchedProduct?.id ?? query,
          timestamp: assessment.timestamp,
          scanCount: 1,
          location,
          status: assessment.level,
          query: assessment.query,
          method,
          riskAssessment: assessment,
        };

        set((s) => ({
          verificationLogs: [...s.verificationLogs, newLog],
          lastRiskAssessment: assessment,
        }));

        return assessment;
      },

      pushToast: (message, type = 'info') => {
        const id = genId('t');
        set((state) => ({
          toasts: [...state.toasts, { id, message, type }],
        }));
        setTimeout(() => {
          get().removeToast(id);
        }, 3500);
      },

      removeToast: (id) => {
        set((state) => ({
          toasts: state.toasts.filter((t) => t.id !== id),
        }));
      },
    }),
    {
      name: 'trustmark-store',
      version: 2,
      partialize: (state) => ({
        products: state.products,
        verificationLogs: state.verificationLogs,
        reports: state.reports,
        blacklistedBatches: state.blacklistedBatches,
      }),
    }
  )
);
