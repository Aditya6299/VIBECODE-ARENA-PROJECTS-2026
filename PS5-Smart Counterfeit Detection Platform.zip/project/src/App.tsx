import { useStore } from '@/store/useStore';
import { Layout } from '@/components/layout/Layout';
import { ToastContainer } from '@/components/ui/Toast';
import { ConsumerPortal } from '@/components/consumer/ConsumerPortal';
import { ReportingPortal } from '@/components/reporting/ReportingPortal';
import { AdminDashboard } from '@/components/admin/AdminDashboard';

export default function App() {
  const activeView = useStore((s) => s.activeView);

  return (
    <Layout>
      {activeView === 'consumer' && <ConsumerPortal />}
      {activeView === 'reporting' && <ReportingPortal />}
      {activeView === 'admin' && <AdminDashboard />}
      <ToastContainer />
    </Layout>
  );
}
