import type { Product, VerificationLog, Report, RiskAssessment } from '@/types';

function makeSeedAssessment(
  productId: string,
  batchNumber: string,
  product: Product | undefined,
  scanCount: number,
  location: string,
  timestamp: string,
  status: 'Genuine' | 'Suspicious' | 'Counterfeit'
): RiskAssessment {
  const score = status === 'Genuine' ? 90 : status === 'Suspicious' ? 45 : 15;
  return {
    level: status,
    score,
    factors: [],
    matchedProduct: product ?? null,
    query: batchNumber,
    method: 'scanner',
    timestamp,
    location,
    scanFrequency: scanCount,
    uniqueLocations: 1,
    isExpired: false,
    isBlacklisted: false,
    visualAnalysis: null,
  };
}

export const seedProducts: Product[] = [
  {
    id: 'p-001',
    brand: 'LuxeAura',
    name: 'Radiance Revival Serum',
    category: 'Cosmetics',
    batchNumber: 'LA-2024-0847',
    manufactureDate: '2024-03-15',
    expiryDate: '2026-03-15',
    referenceImageUrl:
      'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=600',
    authorizedDistributor: 'AuraBeauty Distribution Ltd.',
  },
  {
    id: 'p-002',
    brand: 'PharmaCare',
    name: 'CardioShield 10mg Tablets',
    category: 'Medicines',
    batchNumber: 'PC-2024-3321',
    manufactureDate: '2024-06-01',
    expiryDate: '2026-06-01',
    referenceImageUrl:
      'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600',
    authorizedDistributor: 'MediTrust Pharma Logistics',
  },
  {
    id: 'p-003',
    brand: 'SonicWave',
    name: 'Pro Studio Wireless Headphones',
    category: 'Electronics',
    batchNumber: 'SW-2024-0156',
    manufactureDate: '2024-01-20',
    expiryDate: '2034-01-20',
    referenceImageUrl:
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600',
    authorizedDistributor: 'TechHub Global Supply',
  },
  {
    id: 'p-004',
    brand: 'UrbanThread',
    name: 'Heritage Denim Jacket',
    category: 'Clothing',
    batchNumber: 'UT-2024-7788',
    manufactureDate: '2024-05-10',
    expiryDate: '2034-05-10',
    referenceImageUrl:
      'https://images.unsplash.com/photo-1551538827-9c037cb4f32a?w=600',
    authorizedDistributor: 'Apex Garments Network',
  },
  {
    id: 'p-005',
    brand: 'CleanHome',
    name: 'PowerFresh Surface Cleaner',
    category: 'Consumer Goods',
    batchNumber: 'CH-2024-9912',
    manufactureDate: '2024-08-05',
    expiryDate: '2026-08-05',
    referenceImageUrl:
      'https://images.unsplash.com/photo-1583511666372-62fc56f1a9c5?w=600',
    authorizedDistributor: 'PrimeHousehold Supplies Co.',
  },
  {
    id: 'p-006',
    brand: 'LuxeAura',
    name: 'Velvet Matte Lipstick — Crimson',
    category: 'Cosmetics',
    batchNumber: 'LA-2024-0998',
    manufactureDate: '2024-07-22',
    expiryDate: '2026-07-22',
    referenceImageUrl:
      'https://images.unsplash.com/photo-1586495777744-4413ac210953?w=600',
    authorizedDistributor: 'AuraBeauty Distribution Ltd.',
  },
];

const findP = (id: string) => seedProducts.find((p) => p.id === id);

export const seedVerificationLogs: VerificationLog[] = [
  {
    id: 'v-001',
    productId: 'p-001',
    timestamp: '2024-10-22T14:32:00Z',
    scanCount: 1,
    location: 'New York, USA',
    status: 'Genuine',
    query: 'LA-2024-0847',
    method: 'scanner',
    riskAssessment: makeSeedAssessment('p-001', 'LA-2024-0847', findP('p-001'), 1, 'New York, USA', '2024-10-22T14:32:00Z', 'Genuine'),
  },
  {
    id: 'v-002',
    productId: 'p-003',
    timestamp: '2024-10-21T09:15:00Z',
    scanCount: 4,
    location: 'Mumbai, India',
    status: 'Suspicious',
    query: 'SW-2024-0156',
    method: 'scanner',
    riskAssessment: makeSeedAssessment('p-003', 'SW-2024-0156', findP('p-003'), 4, 'Mumbai, India', '2024-10-21T09:15:00Z', 'Suspicious'),
  },
  {
    id: 'v-003',
    productId: 'p-002',
    timestamp: '2024-10-20T18:45:00Z',
    scanCount: 12,
    location: 'Lagos, Nigeria',
    status: 'Counterfeit',
    query: 'PC-2024-3321',
    method: 'scanner',
    riskAssessment: makeSeedAssessment('p-002', 'PC-2024-3321', findP('p-002'), 12, 'Lagos, Nigeria', '2024-10-20T18:45:00Z', 'Counterfeit'),
  },
  {
    id: 'v-004',
    productId: 'p-004',
    timestamp: '2024-10-19T11:20:00Z',
    scanCount: 2,
    location: 'London, UK',
    status: 'Genuine',
    query: 'UT-2024-7788',
    method: 'manual',
    riskAssessment: makeSeedAssessment('p-004', 'UT-2024-7788', findP('p-004'), 2, 'London, UK', '2024-10-19T11:20:00Z', 'Genuine'),
  },
  {
    id: 'v-005',
    productId: 'p-006',
    timestamp: '2024-10-18T16:05:00Z',
    scanCount: 7,
    location: 'Bangkok, Thailand',
    status: 'Suspicious',
    query: 'LA-2024-0998',
    method: 'scanner',
    riskAssessment: makeSeedAssessment('p-006', 'LA-2024-0998', findP('p-006'), 7, 'Bangkok, Thailand', '2024-10-18T16:05:00Z', 'Suspicious'),
  },
  {
    id: 'v-006',
    productId: 'p-005',
    timestamp: '2024-10-17T08:30:00Z',
    scanCount: 1,
    location: 'Toronto, Canada',
    status: 'Genuine',
    query: 'CH-2024-9912',
    method: 'manual',
    riskAssessment: makeSeedAssessment('p-005', 'CH-2024-9912', findP('p-005'), 1, 'Toronto, Canada', '2024-10-17T08:30:00Z', 'Genuine'),
  },
];

export const seedReports: Report[] = [
  {
    id: 'r-001',
    brand: 'SonicWave',
    productId: 'p-003',
    purchaseLocation: 'Street Market — Patpong, Bangkok',
    consumerNotes:
      'Bought from a night market stall. Packaging looks slightly off and the sound quality is poor compared to my original pair.',
    imageUrl:
      'https://images.unsplash.com/photo-1583394838336-acd9776a394d?w=600',
    status: 'Pending',
    createdAt: '2024-10-22T10:00:00Z',
  },
  {
    id: 'r-002',
    brand: 'PharmaCare',
    productId: 'p-002',
    purchaseLocation: 'Unlicensed Pharmacy — Kano, Nigeria',
    consumerNotes:
      'The blister pack text is blurry and the tablets crumble easily. Batch number does not match any on the official site.',
    imageUrl:
      'https://images.unsplash.com/photo-1631549916768-4119b2e5f926?w=600',
    status: 'Pending',
    createdAt: '2024-10-21T15:30:00Z',
  },
  {
    id: 'r-003',
    brand: 'LuxeAura',
    productId: 'p-001',
    purchaseLocation: 'Online Store — beautydeals2024.com',
    consumerNotes:
      'The serum consistency is watery and the label has a typo. Seller had no return policy and disappeared after purchase.',
    imageUrl:
      'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?w=600',
    status: 'Pending',
    createdAt: '2024-10-20T12:45:00Z',
  },
];
